#!/usr/bin/env python3
"""Convert yWriter to novelWriter

Version 0.1.3
Requires Python 3.7 or above

Copyright (c) 2022 Peter Triesberger
For further information see https://github.com/peter88213/yw2nw
Published under the MIT License (https://opensource.org/licenses/mit-license.php)
"""
import os
import argparse
from pathlib import Path



class Ui():
    """Base class for UI facades, implementing a 'silent mode'.
    """

    def __init__(self, title):
        """Initialize text buffers for messaging.
        """
        self.infoWhatText = ''
        self.infoHowText = ''

    def ask_yes_no(self, text):
        """The application may use a subclass  
        for confirmation requests.    
        """
        return True

    def set_info_what(self, message):
        """What's the converter going to do?"""
        self.infoWhatText = message

    def set_info_how(self, message):
        """How's the converter doing?"""
        self.infoHowText = message

    def start(self):
        """To be overridden by subclasses requiring
        special action to launch the user interaction.
        """


class UiCmd(Ui):
    """Ui subclass implementing a console interface."""

    def __init__(self, title):
        """initialize UI. """
        print(title)

    def ask_yes_no(self, text):
        result = input('WARNING: ' + text + ' (y/n)')

        if result.lower() == 'y':
            return True

        else:
            return False

    def set_info_what(self, message):
        """What's the converter going to do?"""
        print(message)

    def set_info_how(self, message):
        """How's the converter doing?"""
        self.infoHowText = message
        print(message)
from configparser import ConfigParser


class Configuration():
    """Read/write the program configuration.

        INI file sections:
        <self.sLabel> - Strings
        <self.oLabel> - Boolean values

    Instance variables:    
        settings - dictionary of strings
        options - dictionary of boolean values
    """

    def __init__(self, settings={}, options={}):
        """Define attribute variables.

        Arguments:
        settings - default settings (dictionary of strings)
        options - default options (dictionary of boolean values)
        """
        self.sLabel = 'SETTINGS'
        self.oLabel = 'OPTIONS'
        self.set(settings, options)

    def set(self, settings=None, options=None):

        if settings is not None:
            self.settings = settings.copy()

        if options is not None:
            self.options = options.copy()

    def read(self, iniFile):
        """Read a configuration file.
        Settings and options that can not be read in, remain unchanged.
        """
        config = ConfigParser()
        config.read(iniFile)

        if config.has_section(self.sLabel):

            section = config[self.sLabel]

            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)

        if config.has_section(self.oLabel):

            section = config[self.oLabel]

            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def write(self, iniFile):
        """Save the configuration to iniFile.
        """
        config = ConfigParser()

        if self.settings != {}:

            config.add_section(self.sLabel)

            for settingId in self.settings:
                config.set(self.sLabel, settingId, str(self.settings[settingId]))

        if self.options != {}:

            config.add_section(self.oLabel)

            for settingId in self.options:

                if self.options[settingId]:
                    config.set(self.oLabel, settingId, 'Yes')

                else:
                    config.set(self.oLabel, settingId, 'No')

        with open(iniFile, 'w') as f:
            config.write(f)


import sys
import webbrowser



class YwCnv():
    """Base class for Novel file conversion.

    Public methods:
        convert(sourceFile, targetFile) -- Convert sourceFile into targetFile.
    """

    def convert(self, sourceFile, targetFile):
        """Convert sourceFile into targetFile and return a message.

        Positional arguments:
            sourceFile, targetFile -- Novel subclass instances.

        1. Make the source object read the source file.
        2. Make the target object merge the source object's instance variables.
        3. Make the target object write the target file.
        Return a message beginning with SUCCESS or ERROR.

        Error handling:
        - Check if sourceFile and targetFile are correctly initialized.
        - Ask for permission to overwrite targetFile.
        - Pass the error messages of the called methods of sourceFile and targetFile.
        - The success message comes from targetFile.write(), if called.       
        """

        # Initial error handling.

        if sourceFile.filePath is None:
            return 'ERROR: Source "' + os.path.normpath(sourceFile.filePath) + '" is not of the supported type.'

        if not os.path.isfile(sourceFile.filePath):
            return 'ERROR: "' + os.path.normpath(sourceFile.filePath) + '" not found.'

        if targetFile.filePath is None:
            return 'ERROR: Target "' + os.path.normpath(targetFile.filePath) + '" is not of the supported type.'

        if os.path.isfile(targetFile.filePath) and not self.confirm_overwrite(targetFile.filePath):
            return 'ERROR: Action canceled by user.'

        # Make the source object read the source file.

        message = sourceFile.read()

        if message.startswith('ERROR'):
            return message

        # Make the target object merge the source object's instance variables.

        message = targetFile.merge(sourceFile)

        if message.startswith('ERROR'):
            return message

        # Make the source object write the target file.

        return targetFile.write()

    def confirm_overwrite(self, fileName):
        """Return boolean permission to overwrite the target file.
        This is a stub to be overridden by subclass methods.
        """
        return True



class FileFactory:
    """Base class for conversion object factory classes.

    Public methods:
        make_file_objects(self, sourcePath, **kwargs) -- return conversion objects.

    This class emulates a "FileFactory" Interface.
    Instances can be used as stubs for factories instantiated at runtime.
    """

    def __init__(self, fileClasses=[]):
        """Write the parameter to a private instance variable.

        Positional arguments:
            fileClasses -- list of classes from which an instance can be returned.
        """
        self.fileClasses = fileClasses

    def make_file_objects(self, sourcePath, **kwargs):
        """A factory method stub.

        Positional arguments:
            sourcePath -- string; path to the source file to convert.

        Optional arguments:
            suffix -- string; an indicator for the target file type.

        Return a tuple with three elements:
        - A message string starting with 'ERROR'
        - sourceFile: None
        - targetFile: None

        Factory method to be overridden by subclasses.
        Subclasses return a tuple with three elements:
        - A message string starting with 'SUCCESS' or 'ERROR'
        - sourceFile: a Novel subclass instance
        - targetFile: a Novel subclass instance
        """
        return 'ERROR: File type of "' + os.path.normpath(sourcePath) + '" not supported.', None, None



class ExportSourceFactory(FileFactory):
    """A factory class that instantiates a yWriter object to read."""

    def make_file_objects(self, sourcePath, **kwargs):
        """Instantiate a source object for conversion from a yWriter project.
        Override the superclass method.

        Positional arguments:
            sourcePath -- string; path to the source file to convert.

        Return a tuple with three elements:
        - A message string starting with 'SUCCESS' or 'ERROR'
        - sourceFile: a YwFile subclass instance, or None in case of error
        - targetFile: None
        """
        fileName, fileExtension = os.path.splitext(sourcePath)

        for fileClass in self.fileClasses:

            if fileClass.EXTENSION == fileExtension:
                sourceFile = fileClass(sourcePath, **kwargs)
                return 'SUCCESS', sourceFile, None

        return 'ERROR: File type of "' + os.path.normpath(sourcePath) + '" not supported.', None, None



class ExportTargetFactory(FileFactory):
    """A factory class that instantiates a document object to write."""

    def make_file_objects(self, sourcePath, **kwargs):
        """Instantiate a target object for conversion from a yWriter project.
        Override the superclass method.

        Positional arguments:
            sourcePath -- string; path to the source file to convert.

        Optional arguments:
            suffix -- string; an indicator for the target file type.

        Return a tuple with three elements:
        - A message string starting with 'SUCCESS' or 'ERROR'
        - sourceFile: None
        - targetFile: a FileExport subclass instance, or None in case of error 
        """
        fileName, fileExtension = os.path.splitext(sourcePath)
        suffix = kwargs['suffix']

        for fileClass in self.fileClasses:

            if fileClass.SUFFIX == suffix:

                if suffix is None:
                    suffix = ''

                targetFile = fileClass(
                    fileName + suffix + fileClass.EXTENSION, **kwargs)
                return 'SUCCESS', None, targetFile

        return 'ERROR: File type of "' + os.path.normpath(sourcePath) + '" not supported.', None, None


class ImportSourceFactory(FileFactory):
    """A factory class that instantiates a documente object to read."""

    def make_file_objects(self, sourcePath, **kwargs):
        """Instantiate a source object for conversion to a yWriter project.       
        Override the superclass method.

        Positional arguments:
            sourcePath -- string; path to the source file to convert.

        Return a tuple with three elements:
        - A message string starting with 'SUCCESS' or 'ERROR'
        - sourceFile: a Novel subclass instance, or None in case of error
        - targetFile: None
        """

        for fileClass in self.fileClasses:

            if fileClass.SUFFIX is not None:

                if sourcePath.endswith(fileClass.SUFFIX + fileClass.EXTENSION):
                    sourceFile = fileClass(sourcePath, **kwargs)
                    return 'SUCCESS', sourceFile, None

        return 'ERROR: This document is not meant to be written back.', None, None



class ImportTargetFactory(FileFactory):
    """A factory class that instantiates a yWriter object to write."""

    def make_file_objects(self, sourcePath, **kwargs):
        """Instantiate a target object for conversion to a yWriter project.
        Override the superclass method.

        Positional arguments:
            sourcePath -- string; path to the source file to convert.

        Optional arguments:
            suffix -- string; an indicator for the source file type.

        Return a tuple with three elements:
        - A message string starting with 'SUCCESS' or 'ERROR'
        - sourceFile: None
        - targetFile: a YwFile subclass instance, or None in case of error

        """
        fileName, fileExtension = os.path.splitext(sourcePath)
        sourceSuffix = kwargs['suffix']

        if sourceSuffix:
            ywPathBasis = fileName.split(sourceSuffix)[0]

        else:
            ywPathBasis = fileName

        # Look for an existing yWriter project to rewrite.

        for fileClass in self.fileClasses:

            if os.path.isfile(ywPathBasis + fileClass.EXTENSION):
                targetFile = fileClass(
                    ywPathBasis + fileClass.EXTENSION, **kwargs)
                return 'SUCCESS', None, targetFile

        return 'ERROR: No yWriter project to write.', None, None


class YwCnvUi(YwCnv):
    """Base class for Novel file conversion with user interface.

    Public methods:
        run(sourcePath, suffix) -- Create source and target objects and run conversion.

    Class constants:
        EXPORT_SOURCE_CLASSES -- List of YwFile subclasses from which can be exported.
        EXPORT_TARGET_CLASSES -- List of FileExport subclasses to which export is possible.
        IMPORT_SOURCE_CLASSES -- List of Novel subclasses from which can be imported.
        IMPORT_TARGET_CLASSES -- List of YwFile subclasses to which import is possible.

    All lists are empty and meant to be overridden by subclasses.

    Instance variables:
        ui -- Ui (can be overridden e.g. by subclasses).
        exportSourceFactory -- ExportSourceFactory.
        exportTargetFactory -- ExportTargetFactory.
        importSourceFactory -- ImportSourceFactory.
        importTargetFactory -- ImportTargetFactory.
        newProjectFactory -- FileFactory (a stub to be overridden by subclasses).
        newFile -- string; path to the target file in case of success.   
    """

    EXPORT_SOURCE_CLASSES = []
    EXPORT_TARGET_CLASSES = []
    IMPORT_SOURCE_CLASSES = []
    IMPORT_TARGET_CLASSES = []

    def __init__(self):
        """Define instance variables."""
        self.ui = Ui('')
        # Per default, 'silent mode' is active.

        self.exportSourceFactory = ExportSourceFactory(
            self.EXPORT_SOURCE_CLASSES)
        self.exportTargetFactory = ExportTargetFactory(
            self.EXPORT_TARGET_CLASSES)
        self.importSourceFactory = ImportSourceFactory(
            self.IMPORT_SOURCE_CLASSES)
        self.importTargetFactory = ImportTargetFactory(
            self.IMPORT_TARGET_CLASSES)
        self.newProjectFactory = FileFactory()

        self.newFile = None
        # Also indicates successful conversion.

    def run(self, sourcePath, **kwargs):
        """Create source and target objects and run conversion.

        sourcePath -- str; the source file path.
        suffix -- str; target file name suffix. 

        This is a template method that calls primitive operations by case.
        """
        self.newFile = None

        if not os.path.isfile(sourcePath):
            self.ui.set_info_how(
                'ERROR: File "' + os.path.normpath(sourcePath) + '" not found.')
            return

        message, sourceFile, dummy = self.exportSourceFactory.make_file_objects(
            sourcePath, **kwargs)

        if message.startswith('SUCCESS'):
            # The source file is a yWriter project.

            message, dummy, targetFile = self.exportTargetFactory.make_file_objects(
                sourcePath, **kwargs)

            if message.startswith('SUCCESS'):
                self.export_from_yw(sourceFile, targetFile)

            else:
                self.ui.set_info_how(message)

        else:
            # The source file is not a yWriter project.

            message, sourceFile, dummy = self.importSourceFactory.make_file_objects(
                sourcePath, **kwargs)

            if message.startswith('SUCCESS'):
                kwargs['suffix'] = sourceFile.SUFFIX
                message, dummy, targetFile = self.importTargetFactory.make_file_objects(
                    sourcePath, **kwargs)

                if message.startswith('SUCCESS'):
                    self.import_to_yw(sourceFile, targetFile)

                else:
                    self.ui.set_info_how(message)

            else:
                # A new yWriter project might be required.

                message, sourceFile, targetFile = self.newProjectFactory.make_file_objects(
                    sourcePath, **kwargs)

                if message.startswith('SUCCESS'):
                    self.create_yw7(sourceFile, targetFile)

                else:
                    self.ui.set_info_how(message)

    def export_from_yw(self, sourceFile, targetFile):
        """Convert from yWriter project to other file format.

        sourceFile -- YwFile subclass instance.
        targetFile -- Any Novel subclass instance.

        This is a primitive operation of the run() template method.

        1. Send specific information about the conversion to the UI.
        2. Convert sourceFile into targetFile.
        3. Pass the message to the UI.
        4. Save the new file pathname.

        Error handling:
        - If the conversion fails, newFile is set to None.
        """

        # Send specific information about the conversion to the UI.

        self.ui.set_info_what('Input: ' + sourceFile.DESCRIPTION + ' "' + os.path.normpath(
            sourceFile.filePath) + '"\nOutput: ' + targetFile.DESCRIPTION + ' "' + os.path.normpath(targetFile.filePath) + '"')

        # Convert sourceFile into targetFile.

        message = self.convert(sourceFile, targetFile)

        # Pass the message to the UI.

        self.ui.set_info_how(message)

        # Save the new file pathname.

        if message.startswith('SUCCESS'):
            self.newFile = targetFile.filePath

        else:
            self.newFile = None

    def create_yw7(self, sourceFile, targetFile):
        """Create targetFile from sourceFile.

        sourceFile -- Any Novel subclass instance.
        targetFile -- YwFile subclass instance.

        This is a primitive operation of the run() template method.

        1. Send specific information about the conversion to the UI.
        2. Convert sourceFile into targetFile.
        3. Pass the message to the UI.
        4. Save the new file pathname.

        Error handling:
        - Tf targetFile already exists as a file, the conversion is cancelled,
          an error message is sent to the UI.
        - If the conversion fails, newFile is set to None.
        """

        # Send specific information about the conversion to the UI.

        self.ui.set_info_what(
            'Create a yWriter project file from ' + sourceFile.DESCRIPTION + '\nNew project: "' + os.path.normpath(targetFile.filePath) + '"')

        if os.path.isfile(targetFile.filePath):
            self.ui.set_info_how('ERROR: "' + os.path.normpath(targetFile.filePath) + '" already exists.')

        else:
            # Convert sourceFile into targetFile.

            message = self.convert(sourceFile, targetFile)

            # Pass the message to the UI.

            self.ui.set_info_how(message)

            # Save the new file pathname.

            if message.startswith('SUCCESS'):
                self.newFile = targetFile.filePath

            else:
                self.newFile = None

    def import_to_yw(self, sourceFile, targetFile):
        """Convert from any file format to yWriter project.

        sourceFile -- Any Novel subclass instance.
        targetFile -- YwFile subclass instance.

        This is a primitive operation of the run() template method.

        1. Send specific information about the conversion to the UI.
        2. Convert sourceFile into targetFile.
        3. Pass the message to the UI.
        4. Delete the temporay file, if exists.
        5. Save the new file pathname.

        Error handling:
        - If the conversion fails, newFile is set to None.
        """

        # Send specific information about the conversion to the UI.

        self.ui.set_info_what('Input: ' + sourceFile.DESCRIPTION + ' "' + os.path.normpath(
            sourceFile.filePath) + '"\nOutput: ' + targetFile.DESCRIPTION + ' "' + os.path.normpath(targetFile.filePath) + '"')

        # Convert sourceFile into targetFile.

        message = self.convert(sourceFile, targetFile)

        # Pass the message to the UI.

        self.ui.set_info_how(message)

        # Delete the temporay file, if exists.

        self.delete_tempfile(sourceFile.filePath)

        # Save the new file pathname.

        if message.startswith('SUCCESS'):
            self.newFile = targetFile.filePath

        else:
            self.newFile = None

    def confirm_overwrite(self, filePath):
        """Return boolean permission to overwrite the target file, overriding the superclass method."""
        return self.ui.ask_yes_no('Overwrite existing file "' + os.path.normpath(filePath) + '"?')

    def delete_tempfile(self, filePath):
        """Delete filePath if it is a temporary file no longer needed."""

        if filePath.endswith('.html'):
            # Might it be a temporary text document?

            if os.path.isfile(filePath.replace('.html', '.odt')):
                # Does a corresponding Office document exist?

                try:
                    os.remove(filePath)

                except:
                    pass

        elif filePath.endswith('.csv'):
            # Might it be a temporary spreadsheet document?

            if os.path.isfile(filePath.replace('.csv', '.ods')):
                # Does a corresponding Office document exist?

                try:
                    os.remove(filePath)

                except:
                    pass

    def open_newFile(self):
        """Open the converted file for editing and exit the converter script."""
        webbrowser.open(self.newFile)
        sys.exit(0)


from urllib.parse import quote
from shutil import copy2


class Novel():
    """Abstract yWriter project file representation.

    This class represents a file containing a novel with additional 
    attributes and structural information (a full set or a subset
    of the information included in an yWriter project file).

    Public methods: 
        read() -- Parse the file and store selected properties.
        merge(novel) -- Copy required attributes of the novel object.
        write() -- Write selected properties to the file.
        convert_to_yw(text) -- Return text, converted from source format to yw7 markup.
        convert_from_yw(text) -- Return text, converted from yw7 markup to target format.
        file_exists() -- Return True, if the file specified by filePath exists.
        back_up() -- Create a backup file from filePath.

    Instance variables:
        title -- str; title
        desc -- str; description
        author -- str; author name
        fieldTitle1 -- str; field title 1
        fieldTitle2 -- str; field title 2
        fieldTitle3 -- str; field title 3
        fieldTitle4 -- str; field title 4
        chapters -- dict; key = chapter ID, value = Chapter instance.
        scenes -- dict; key = scene ID, value = Scene instance.
        srtChapters -- list of str; The novel's sorted chapter IDs. 
        locations -- dict; key = location ID, value = WorldElement instance.
        srtLocations -- list of str; The novel's sorted location IDs. 
        items -- dict; key = item ID, value = WorldElement instance.
        srtItems -- list of str; The novel's sorted item IDs. 
        characters -- dict; key = character ID, value = Character instance.
        srtCharacters -- list of str The novel's sorted character IDs.
        filePath -- str; path to the file represented by the class.   
    """

    DESCRIPTION = 'Novel'
    EXTENSION = None
    SUFFIX = None
    # To be extended by subclass methods.

    def __init__(self, filePath, **kwargs):
        """Define instance variables.

        Positional argument:
            filePath -- string; path to the file represented by the class.
        """
        self.title = None
        # str
        # xml: <PROJECT><Title>

        self.desc = None
        # str
        # xml: <PROJECT><Desc>

        self.author = None
        # str
        # xml: <PROJECT><AuthorName>

        self.fieldTitle1 = None
        # str
        # xml: <PROJECT><FieldTitle1>

        self.fieldTitle2 = None
        # str
        # xml: <PROJECT><FieldTitle2>

        self.fieldTitle3 = None
        # str
        # xml: <PROJECT><FieldTitle3>

        self.fieldTitle4 = None
        # str
        # xml: <PROJECT><FieldTitle4>

        self.chapters = {}
        # dict
        # xml: <CHAPTERS><CHAPTER><ID>
        # key = chapter ID, value = Chapter instance.
        # The order of the elements does not matter (the novel's
        # order of the chapters is defined by srtChapters)

        self.scenes = {}
        # dict
        # xml: <SCENES><SCENE><ID>
        # key = scene ID, value = Scene instance.
        # The order of the elements does not matter (the novel's
        # order of the scenes is defined by the order of the chapters
        # and the order of the scenes within the chapters)

        self.srtChapters = []
        # list of str
        # The novel's chapter IDs. The order of its elements
        # corresponds to the novel's order of the chapters.

        self.locations = {}
        # dict
        # xml: <LOCATIONS>
        # key = location ID, value = WorldElement instance.
        # The order of the elements does not matter.

        self.srtLocations = []
        # list of str
        # The novel's location IDs. The order of its elements
        # corresponds to the XML project file.

        self.items = {}
        # dict
        # xml: <ITEMS>
        # key = item ID, value = WorldElement instance.
        # The order of the elements does not matter.

        self.srtItems = []
        # list of str
        # The novel's item IDs. The order of its elements
        # corresponds to the XML project file.

        self.characters = {}
        # dict
        # xml: <CHARACTERS>
        # key = character ID, value = Character instance.
        # The order of the elements does not matter.

        self.srtCharacters = []
        # list of str
        # The novel's character IDs. The order of its elements
        # corresponds to the XML project file.

        self._filePath = None
        # str
        # Path to the file. The setter only accepts files of a
        # supported type as specified by EXTENSION.

        self._projectName = None
        # str
        # URL-coded file name without suffix and extension.

        self._projectPath = None
        # str
        # URL-coded path to the project directory.

        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath):
        """Setter for the filePath instance variable.        
        - Format the path string according to Python's requirements. 
        - Accept only filenames with the right suffix and extension.
        """

        if self.SUFFIX is not None:
            suffix = self.SUFFIX

        else:
            suffix = ''

        if filePath.lower().endswith((suffix + self.EXTENSION).lower()):
            self._filePath = filePath
            head, tail = os.path.split(os.path.realpath(filePath))
            self.projectPath = quote(head.replace('\\', '/'), '/:')
            self.projectName = quote(tail.replace(
                suffix + self.EXTENSION, ''))

    def read(self):
        """Parse the file and store selected properties.
        Return a message beginning with SUCCESS or ERROR.
        This is a stub to be overridden by subclass methods.
        """
        return 'ERROR: read method is not implemented.'

    def merge(self, source):
        """Copy required attributes of the source object.
        Return a message beginning with SUCCESS or ERROR.
        This is a stub to be overridden by subclass methods.
        """
        return 'ERROR: merge method is not implemented.'

    def write(self):
        """Write selected properties to the file.
        Return a message beginning with SUCCESS or ERROR.
        This is a stub to be overridden by subclass methods.
        """
        return 'ERROR: write method is not implemented.'

    def convert_to_yw(self, text):
        """Return text, converted from source format to yw7 markup.
        This is a stub to be overridden by subclass methods.
        """
        return text

    def convert_from_yw(self, text):
        """Return text, converted from yw7 markup to target format.
        This is a stub to be overridden by subclass methods.
        """
        return text

    def file_exists(self):
        """Return True, if the file specified by filePath exists. 
        Otherwise, return False.

        DEPRECATED -- This method is no longer provided for v4.
        """
        if os.path.isfile(self.filePath):
            return True

        else:
            return False

    def back_up(self, single=True):
        """Create a backup file from filePath. Return True, if successful.
        Otherwise, return False.

        Parameter: single
        True - Overwrite existing backup file. Extension = .bak
        False - Create a new, numbered backup file. Extension = .bkxxxx

        DEPRECATED -- This method is no longer provided for v4.
        """
        if os.path.isfile(self.filePath):

            if single:
                backupFile = self.filePath + '.bak'

            else:
                i = 0
                backupFile = self.filePath + '.bk0000'

                while os.path.isfile(backupFile):
                    i += 1
                    backupFile = self.filePath + '.bk' + str(i).zfill(4)

            try:
                copy2(self.filePath, backupFile)
                return True

            except:
                return False

        else:
            return False


class Chapter():
    """yWriter chapter representation.
    # xml: <CHAPTERS><CHAPTER>
    """

    chapterTitlePrefix = "Chapter "
    # str
    # Can be changed at runtime for non-English projects.

    def __init__(self):
        self.title = None
        # str
        # xml: <Title>

        self.desc = None
        # str
        # xml: <Desc>

        self.chLevel = None
        # int
        # xml: <SectionStart>
        # 0 = chapter level
        # 1 = section level ("this chapter begins a section")

        self.oldType = None
        # int
        # xml: <Type>
        # 0 = chapter type (marked "Chapter")
        # 1 = other type (marked "Other")

        self.chType = None
        # int
        # xml: <ChapterType>
        # 0 = Normal
        # 1 = Notes
        # 2 = Todo

        self.isUnused = None
        # bool
        # xml: <Unused> -1

        self.suppressChapterTitle = None
        # bool
        # xml: <Fields><Field_SuppressChapterTitle> 1
        # True: Chapter heading not to be displayed in written document.
        # False: Chapter heading to be displayed in written document.

        self.isTrash = None
        # bool
        # xml: <Fields><Field_IsTrash> 1
        # True: This chapter is the yw7 project's "trash bin".
        # False: This chapter is not a "trash bin".

        self.suppressChapterBreak = None
        # bool
        # xml: <Fields><Field_SuppressChapterBreak> 0

        self.srtScenes = []
        # list of str
        # xml: <Scenes><ScID>
        # The chapter's scene IDs. The order of its elements
        # corresponds to the chapter's order of the scenes.

    def get_title(self):
        """Fix auto-chapter titles if necessary 
        """
        text = self.title

        if text:
            text = text.replace('Chapter ', self.chapterTitlePrefix)

        return text
import re


class Scene():
    """yWriter scene representation.
    # xml: <SCENES><SCENE>
    """

    # Emulate an enumeration for the scene status
    # Since the items are used to replace text,
    # they may contain spaces. This is why Enum cannot be used here.

    STATUS = [None, 'Outline', 'Draft', '1st Edit', '2nd Edit', 'Done']
    ACTION_MARKER = 'A'
    REACTION_MARKER = 'R'

    NULL_DATE = '0001-01-01'
    NULL_TIME = '00:00:00'

    def __init__(self):
        self.title = None
        # str
        # xml: <Title>

        self.desc = None
        # str
        # xml: <Desc>

        self._sceneContent = None
        # str
        # xml: <SceneContent>
        # Scene text with yW7 raw markup.

        self.rtfFile = None
        # str
        # xml: <RTFFile>
        # Name of the file containing the scene in yWriter 5.

        self.wordCount = 0
        # int # xml: <WordCount>
        # To be updated by the sceneContent setter

        self.letterCount = 0
        # int
        # xml: <LetterCount>
        # To be updated by the sceneContent setter

        self.isUnused = None
        # bool
        # xml: <Unused> -1

        self.isNotesScene = None
        # bool
        # xml: <Fields><Field_SceneType> 1

        self.isTodoScene = None
        # bool
        # xml: <Fields><Field_SceneType> 2

        self.doNotExport = None
        # bool
        # xml: <ExportCondSpecific><ExportWhenRTF>

        self.status = None
        # int
        # xml: <Status>
        # 1 - Outline
        # 2 - Draft
        # 3 - 1st Edit
        # 4 - 2nd Edit
        # 5 - Done
        # See also the STATUS list for conversion.

        self.sceneNotes = None
        # str
        # xml: <Notes>

        self.tags = None
        # list of str
        # xml: <Tags>

        self.field1 = None
        # str
        # xml: <Field1>

        self.field2 = None
        # str
        # xml: <Field2>

        self.field3 = None
        # str
        # xml: <Field3>

        self.field4 = None
        # str
        # xml: <Field4>

        self.appendToPrev = None
        # bool
        # xml: <AppendToPrev> -1

        self.isReactionScene = None
        # bool
        # xml: <ReactionScene> -1

        self.isSubPlot = None
        # bool
        # xml: <SubPlot> -1

        self.goal = None
        # str
        # xml: <Goal>

        self.conflict = None
        # str
        # xml: <Conflict>

        self.outcome = None
        # str
        # xml: <Outcome>

        self.characters = None
        # list of str
        # xml: <Characters><CharID>

        self.locations = None
        # list of str
        # xml: <Locations><LocID>

        self.items = None
        # list of str
        # xml: <Items><ItemID>

        self.date = None
        # str
        # xml: <SpecificDateMode>-1
        # xml: <SpecificDateTime>1900-06-01 20:38:00

        self.time = None
        # str
        # xml: <SpecificDateMode>-1
        # xml: <SpecificDateTime>1900-06-01 20:38:00

        self.minute = None
        # str
        # xml: <Minute>

        self.hour = None
        # str
        # xml: <Hour>

        self.day = None
        # str
        # xml: <Day>

        self.lastsMinutes = None
        # str
        # xml: <LastsMinutes>

        self.lastsHours = None
        # str
        # xml: <LastsHours>

        self.lastsDays = None
        # str
        # xml: <LastsDays>

        self.image = None
        # str
        # xml: <ImageFile>

    @property
    def sceneContent(self):
        return self._sceneContent

    @sceneContent.setter
    def sceneContent(self, text):
        """Set sceneContent updating word count and letter count."""
        self._sceneContent = text
        text = re.sub('\[.+?\]|\.|\,| -', '', self._sceneContent)
        # Remove yWriter raw markup for word count

        wordList = text.split()
        self.wordCount = len(wordList)

        text = re.sub('\[.+?\]', '', self._sceneContent)
        # Remove yWriter raw markup for letter count

        text = text.replace('\n', '')
        text = text.replace('\r', '')
        self.letterCount = len(text)



class WorldElement():
    """Story world element representation.
    # xml: <LOCATIONS><LOCATION> or # xml: <ITEMS><ITEM>
    """

    def __init__(self):
        self.title = None
        # str
        # xml: <Title>

        self.image = None
        # str
        # xml: <ImageFile>

        self.desc = None
        # str
        # xml: <Desc>

        self.tags = None
        # list of str
        # xml: <Tags>

        self.aka = None
        # str
        # xml: <AKA>


class Character(WorldElement):
    """yWriter character representation.
    # xml: <CHARACTERS><CHARACTER>
    """

    MAJOR_MARKER = 'Major'
    MINOR_MARKER = 'Minor'

    def __init__(self):
        WorldElement.__init__(self)

        self.notes = None
        # str
        # xml: <Notes>

        self.bio = None
        # str
        # xml: <Bio>

        self.goals = None
        # str
        # xml: <Goals>

        self.fullName = None
        # str
        # xml: <FullName>

        self.isMajor = None
        # bool
        # xml: <Major>


import xml.etree.ElementTree as ET


def indent(elem, level=0):
    """xml pretty printer

    Kudos to to Fredrik Lundh. 
    Source: http://effbot.org/zone/element-lib.htm#prettyprint
    """
    i = "\n" + level * "  "

    if len(elem):

        if not elem.text or not elem.text.strip():
            elem.text = i + "  "

        if not elem.tail or not elem.tail.strip():
            elem.tail = i

        for elem in elem:
            indent(elem, level + 1)

        if not elem.tail or not elem.tail.strip():
            elem.tail = i

    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


class Yw7TreeBuilder():
    """Build yWriter 7 project xml tree."""

    TAG = 'YWRITER7'
    VER = '7'

    def build_element_tree(self, ywProject):
        """Modify the yWriter project attributes of an existing xml element tree.
        Return a message beginning with SUCCESS or ERROR.
        """

        def build_scene_subtree(xmlScn, prjScn):

            if prjScn.title is not None:

                try:
                    xmlScn.find('Title').text = prjScn.title

                except(AttributeError):
                    ET.SubElement(xmlScn, 'Title').text = prjScn.title

            if xmlScn.find('BelongsToChID') is None:

                for chId in ywProject.chapters:

                    if scId in ywProject.chapters[chId].srtScenes:
                        ET.SubElement(xmlScn, 'BelongsToChID').text = chId
                        break

            if prjScn.desc is not None:

                try:
                    xmlScn.find('Desc').text = prjScn.desc

                except(AttributeError):
                    ET.SubElement(xmlScn, 'Desc').text = prjScn.desc

            # Scene content is overwritten in subclasses.

            if xmlScn.find('SceneContent') is None:
                ET.SubElement(xmlScn, 'SceneContent').text = prjScn.sceneContent

            if xmlScn.find('WordCount') is None:
                ET.SubElement(xmlScn, 'WordCount').text = str(prjScn.wordCount)

            if xmlScn.find('LetterCount') is None:
                ET.SubElement(xmlScn, 'LetterCount').text = str(prjScn.letterCount)

            if prjScn.isUnused:

                if xmlScn.find('Unused') is None:
                    ET.SubElement(xmlScn, 'Unused').text = '-1'

            elif xmlScn.find('Unused') is not None:
                xmlScn.remove(xmlScn.find('Unused'))

            if prjScn.isNotesScene:
                scFields = xmlScn.find('Fields')

                try:
                    scFields.find('Field_SceneType').text = '1'

                except(AttributeError):
                    scFields = ET.SubElement(xmlScn, 'Fields')
                    ET.SubElement(scFields, 'Field_SceneType').text = '1'

            elif xmlScn.find('Fields') is not None:
                scFields = xmlScn.find('Fields')

                if scFields.find('Field_SceneType') is not None:

                    if scFields.find('Field_SceneType').text == '1':
                        scFields.remove(scFields.find('Field_SceneType'))

            if prjScn.isTodoScene:
                scFields = xmlScn.find('Fields')

                try:
                    scFields.find('Field_SceneType').text = '2'

                except(AttributeError):
                    scFields = ET.SubElement(xmlScn, 'Fields')
                    ET.SubElement(scFields, 'Field_SceneType').text = '2'

            elif xmlScn.find('Fields') is not None:
                scFields = xmlScn.find('Fields')

                if scFields.find('Field_SceneType') is not None:

                    if scFields.find('Field_SceneType').text == '2':
                        scFields.remove(scFields.find('Field_SceneType'))

            if prjScn.status is not None:
                try:
                    xmlScn.find('Status').text = str(prjScn.status)

                except:
                    ET.SubElement(xmlScn, 'Status').text = str(prjScn.status)

            if prjScn.sceneNotes is not None:

                try:
                    xmlScn.find('Notes').text = prjScn.sceneNotes

                except(AttributeError):
                    ET.SubElement(xmlScn, 'Notes').text = prjScn.sceneNotes

            if prjScn.tags is not None:

                try:
                    xmlScn.find('Tags').text = ';'.join(prjScn.tags)

                except(AttributeError):
                    ET.SubElement(xmlScn, 'Tags').text = ';'.join(prjScn.tags)

            if prjScn.field1 is not None:

                try:
                    xmlScn.find('Field1').text = prjScn.field1

                except(AttributeError):
                    ET.SubElement(xmlScn, 'Field1').text = prjScn.field1

            if prjScn.field2 is not None:

                try:
                    xmlScn.find('Field2').text = prjScn.field2

                except(AttributeError):
                    ET.SubElement(xmlScn, 'Field2').text = prjScn.field2

            if prjScn.field3 is not None:

                try:
                    xmlScn.find('Field3').text = prjScn.field3

                except(AttributeError):
                    ET.SubElement(xmlScn, 'Field3').text = prjScn.field3

            if prjScn.field4 is not None:

                try:
                    xmlScn.find('Field4').text = prjScn.field4

                except(AttributeError):
                    ET.SubElement(xmlScn, 'Field4').text = prjScn.field4

            if prjScn.appendToPrev:

                if xmlScn.find('AppendToPrev') is None:
                    ET.SubElement(xmlScn, 'AppendToPrev').text = '-1'

            elif xmlScn.find('AppendToPrev') is not None:
                xmlScn.remove(xmlScn.find('AppendToPrev'))

            # Date/time information

            if (prjScn.date is not None) and (prjScn.time is not None):
                dateTime = prjScn.date + ' ' + prjScn.time

                if xmlScn.find('SpecificDateTime') is not None:
                    xmlScn.find('SpecificDateTime').text = dateTime

                else:
                    ET.SubElement(xmlScn, 'SpecificDateTime').text = dateTime
                    ET.SubElement(xmlScn, 'SpecificDateMode').text = '-1'

                    if xmlScn.find('Day') is not None:
                        xmlScn.remove(xmlScn.find('Day'))

                    if xmlScn.find('Hour') is not None:
                        xmlScn.remove(xmlScn.find('Hour'))

                    if xmlScn.find('Minute') is not None:
                        xmlScn.remove(xmlScn.find('Minute'))

            elif (prjScn.day is not None) or (prjScn.hour is not None) or (prjScn.minute is not None):

                if xmlScn.find('SpecificDateTime') is not None:
                    xmlScn.remove(xmlScn.find('SpecificDateTime'))

                if xmlScn.find('SpecificDateMode') is not None:
                    xmlScn.remove(xmlScn.find('SpecificDateMode'))

                if prjScn.day is not None:

                    try:
                        xmlScn.find('Day').text = prjScn.day

                    except(AttributeError):
                        ET.SubElement(xmlScn, 'Day').text = prjScn.day

                if prjScn.hour is not None:

                    try:
                        xmlScn.find('Hour').text = prjScn.hour

                    except(AttributeError):
                        ET.SubElement(xmlScn, 'Hour').text = prjScn.hour

                if prjScn.minute is not None:

                    try:
                        xmlScn.find('Minute').text = prjScn.minute

                    except(AttributeError):
                        ET.SubElement(xmlScn, 'Minute').text = prjScn.minute

            if prjScn.lastsDays is not None:

                try:
                    xmlScn.find('LastsDays').text = prjScn.lastsDays

                except(AttributeError):
                    ET.SubElement(xmlScn, 'LastsDays').text = prjScn.lastsDays

            if prjScn.lastsHours is not None:

                try:
                    xmlScn.find('LastsHours').text = prjScn.lastsHours

                except(AttributeError):
                    ET.SubElement(xmlScn, 'LastsHours').text = prjScn.lastsHours

            if prjScn.lastsMinutes is not None:

                try:
                    xmlScn.find('LastsMinutes').text = prjScn.lastsMinutes

                except(AttributeError):
                    ET.SubElement(xmlScn, 'LastsMinutes').text = prjScn.lastsMinutes

            # Plot related information

            if prjScn.isReactionScene:

                if xmlScn.find('ReactionScene') is None:
                    ET.SubElement(xmlScn, 'ReactionScene').text = '-1'

            elif xmlScn.find('ReactionScene') is not None:
                xmlScn.remove(xmlScn.find('ReactionScene'))

            if prjScn.isSubPlot:

                if xmlScn.find('SubPlot') is None:
                    ET.SubElement(xmlScn, 'SubPlot').text = '-1'

            elif xmlScn.find('SubPlot') is not None:
                xmlScn.remove(xmlScn.find('SubPlot'))

            if prjScn.goal is not None:

                try:
                    xmlScn.find('Goal').text = prjScn.goal

                except(AttributeError):
                    ET.SubElement(xmlScn, 'Goal').text = prjScn.goal

            if prjScn.conflict is not None:

                try:
                    xmlScn.find('Conflict').text = prjScn.conflict

                except(AttributeError):
                    ET.SubElement(xmlScn, 'Conflict').text = prjScn.conflict

            if prjScn.outcome is not None:

                try:
                    xmlScn.find('Outcome').text = prjScn.outcome

                except(AttributeError):
                    ET.SubElement(xmlScn, 'Outcome').text = prjScn.outcome

            if prjScn.image is not None:

                try:
                    xmlScn.find('ImageFile').text = prjScn.image

                except(AttributeError):
                    ET.SubElement(xmlScn, 'ImageFile').text = prjScn.image

            if prjScn.characters is not None:
                characters = xmlScn.find('Characters')

                try:
                    for oldCrId in characters.findall('CharID'):
                        characters.remove(oldCrId)

                except(AttributeError):
                    characters = ET.SubElement(xmlScn, 'Characters')

                for crId in prjScn.characters:
                    ET.SubElement(characters, 'CharID').text = crId

            if prjScn.locations is not None:
                locations = xmlScn.find('Locations')

                try:
                    for oldLcId in locations.findall('LocID'):
                        locations.remove(oldLcId)

                except(AttributeError):
                    locations = ET.SubElement(xmlScn, 'Locations')

                for lcId in prjScn.locations:
                    ET.SubElement(locations, 'LocID').text = lcId

            if prjScn.items is not None:
                items = xmlScn.find('Items')

                try:
                    for oldItId in items.findall('ItemID'):
                        items.remove(oldItId)

                except(AttributeError):
                    items = ET.SubElement(xmlScn, 'Items')

                for itId in prjScn.items:
                    ET.SubElement(items, 'ItemID').text = itId

        def build_chapter_subtree(xmlChp, prjChp, sortOrder):

            try:
                xmlChp.find('SortOrder').text = str(sortOrder)

            except(AttributeError):
                ET.SubElement(xmlChp, 'SortOrder').text = str(sortOrder)

            try:
                xmlChp.find('Title').text = prjChp.title

            except(AttributeError):
                ET.SubElement(xmlChp, 'Title').text = prjChp.title

            if prjChp.desc is not None:

                try:
                    xmlChp.find('Desc').text = prjChp.desc

                except(AttributeError):
                    ET.SubElement(xmlChp, 'Desc').text = prjChp.desc

            if xmlChp.find('SectionStart') is not None:

                if prjChp.chLevel == 0:
                    xmlChp.remove(xmlChp.find('SectionStart'))

            elif prjChp.chLevel == 1:
                ET.SubElement(xmlChp, 'SectionStart').text = '-1'

            if prjChp.oldType is not None:

                try:
                    xmlChp.find('Type').text = str(prjChp.oldType)

                except(AttributeError):
                    ET.SubElement(xmlChp, 'Type').text = str(prjChp.oldType)

            if prjChp.chType is not None:

                try:
                    xmlChp.find('ChapterType').text = str(prjChp.chType)

                except(AttributeError):
                    ET.SubElement(xmlChp, 'ChapterType').text = str(prjChp.chType)

            if prjChp.isUnused:

                if xmlChp.find('Unused') is None:
                    ET.SubElement(xmlChp, 'Unused').text = '-1'

            elif xmlChp.find('Unused') is not None:
                xmlChp.remove(xmlChp.find('Unused'))

            #--- Rebuild the chapter's scene list.

            if prjChp.srtScenes:
                xScnList = xmlChp.find('Scenes')

                if xScnList is not None:
                    xmlChp.remove(xScnList)

                sortSc = ET.SubElement(xmlChp, 'Scenes')

                for scId in prjChp.srtScenes:
                    ET.SubElement(sortSc, 'ScID').text = scId

        def build_location_subtree(xmlLoc, prjLoc, sortOrder):
            ET.SubElement(xmlLoc, 'ID').text = lcId

            if prjLoc.title is not None:
                ET.SubElement(xmlLoc, 'Title').text = prjLoc.title

            if prjLoc.image is not None:
                ET.SubElement(xmlLoc, 'ImageFile').text = prjLoc.image

            if prjLoc.desc is not None:
                ET.SubElement(xmlLoc, 'Desc').text = prjLoc.desc

            if prjLoc.aka is not None:
                ET.SubElement(xmlLoc, 'AKA').text = prjLoc.aka

            if prjLoc.tags is not None:
                ET.SubElement(xmlLoc, 'Tags').text = ';'.join(prjLoc.tags)

            ET.SubElement(xmlLoc, 'SortOrder').text = str(sortOrder)

        def build_item_subtree(xmlItm, prjItm, sortOrder):
            ET.SubElement(xmlItm, 'ID').text = itId

            if prjItm.title is not None:
                ET.SubElement(xmlItm, 'Title').text = prjItm.title

            if prjItm.image is not None:
                ET.SubElement(xmlItm, 'ImageFile').text = prjItm.image

            if prjItm.desc is not None:
                ET.SubElement(xmlItm, 'Desc').text = prjItm.desc

            if prjItm.aka is not None:
                ET.SubElement(xmlItm, 'AKA').text = prjItm.aka

            if prjItm.tags is not None:
                ET.SubElement(xmlItm, 'Tags').text = ';'.join(prjItm.tags)

            ET.SubElement(xmlItm, 'SortOrder').text = str(sortOrder)

        def build_character_subtree(xmlCrt, prjCrt, sortOrder):
            ET.SubElement(xmlCrt, 'ID').text = crId

            if prjCrt.title is not None:
                ET.SubElement(xmlCrt, 'Title').text = prjCrt.title

            if prjCrt.desc is not None:
                ET.SubElement(xmlCrt, 'Desc').text = prjCrt.desc

            if prjCrt.image is not None:
                ET.SubElement(xmlCrt, 'ImageFile').text = prjCrt.image

            ET.SubElement(xmlCrt, 'SortOrder').text = str(sortOrder)

            if prjCrt.notes is not None:
                ET.SubElement(xmlCrt, 'Notes').text = prjCrt.notes

            if prjCrt.aka is not None:
                ET.SubElement(xmlCrt, 'AKA').text = prjCrt.aka

            if prjCrt.tags is not None:
                ET.SubElement(xmlCrt, 'Tags').text = ';'.join(prjCrt.tags)

            if prjCrt.bio is not None:
                ET.SubElement(xmlCrt, 'Bio').text = prjCrt.bio

            if prjCrt.goals is not None:
                ET.SubElement(xmlCrt, 'Goals').text = prjCrt.goals

            if prjCrt.fullName is not None:
                ET.SubElement(xmlCrt, 'FullName').text = prjCrt.fullName

            if prjCrt.isMajor:
                ET.SubElement(xmlCrt, 'Major').text = '-1'

        def build_project_subtree(xmlPrj, ywProject):

            try:
                xmlPrj.find('Ver').text = self.VER

            except(AttributeError):
                ET.SubElement(xmlPrj, 'Ver').text = self.VER

            if ywProject.title is not None:

                try:
                    xmlPrj.find('Title').text = ywProject.title

                except(AttributeError):
                    ET.SubElement(xmlPrj, 'Title').text = ywProject.title

            if ywProject.desc is not None:

                try:
                    xmlPrj.find('Desc').text = ywProject.desc

                except(AttributeError):
                    ET.SubElement(xmlPrj, 'Desc').text = ywProject.desc

            if ywProject.author is not None:

                try:
                    xmlPrj.find('AuthorName').text = ywProject.author

                except(AttributeError):
                    ET.SubElement(xmlPrj, 'AuthorName').text = ywProject.author

            if ywProject.fieldTitle1 is not None:

                try:
                    xmlPrj.find('FieldTitle1').text = ywProject.fieldTitle1

                except(AttributeError):
                    ET.SubElement(xmlPrj, 'FieldTitle1').text = ywProject.fieldTitle1

            if ywProject.fieldTitle2 is not None:

                try:
                    xmlPrj.find('FieldTitle2').text = ywProject.fieldTitle2

                except(AttributeError):
                    ET.SubElement(xmlPrj, 'FieldTitle2').text = ywProject.fieldTitle2

            if ywProject.fieldTitle3 is not None:

                try:
                    xmlPrj.find('FieldTitle3').text = ywProject.fieldTitle3

                except(AttributeError):
                    ET.SubElement(xmlPrj, 'FieldTitle3').text = ywProject.fieldTitle3

            if ywProject.fieldTitle4 is not None:

                try:
                    xmlPrj.find('FieldTitle4').text = ywProject.fieldTitle4

                except(AttributeError):
                    ET.SubElement(xmlPrj, 'FieldTitle4').text = ywProject.fieldTitle4

        xmlScenes = {}
        xmlChapters = {}

        try:
            root = ywProject.tree.getroot()
            xmlPrj = root.find('PROJECT')
            locations = root.find('LOCATIONS')
            items = root.find('ITEMS')
            characters = root.find('CHARACTERS')
            scenes = root.find('SCENES')
            chapters = root.find('CHAPTERS')

        except(AttributeError):
            root = ET.Element(self.TAG)
            xmlPrj = ET.SubElement(root, 'PROJECT')
            locations = ET.SubElement(root, 'LOCATIONS')
            items = ET.SubElement(root, 'ITEMS')
            characters = ET.SubElement(root, 'CHARACTERS')
            scenes = ET.SubElement(root, 'SCENES')
            chapters = ET.SubElement(root, 'CHAPTERS')

        #--- Process project attributes.

        build_project_subtree(xmlPrj, ywProject)

        #--- Process locations.
        # Remove LOCATION entries in order to rewrite
        # the LOCATIONS section in a modified sort order.

        for xmlLoc in locations.findall('LOCATION'):
            locations.remove(xmlLoc)

        # Add the new XML location subtrees to the project tree.

        sortOrder = 0

        for lcId in ywProject.srtLocations:
            sortOrder += 1
            xmlLoc = ET.SubElement(locations, 'LOCATION')
            build_location_subtree(xmlLoc, ywProject.locations[lcId], sortOrder)

        #--- Process items.
        # Remove ITEM entries in order to rewrite
        # the ITEMS section in a modified sort order.

        for xmlItm in items.findall('ITEM'):
            items.remove(xmlItm)

        # Add the new XML item subtrees to the project tree.

        sortOrder = 0

        for itId in ywProject.srtItems:
            sortOrder += 1
            xmlItm = ET.SubElement(items, 'ITEM')
            build_item_subtree(xmlItm, ywProject.items[itId], sortOrder)

        #--- Process characters.
        # Remove CHARACTER entries in order to rewrite
        # the CHARACTERS section in a modified sort order.

        for xmlCrt in characters.findall('CHARACTER'):
            characters.remove(xmlCrt)

        # Add the new XML character subtrees to the project tree.

        sortOrder = 0

        for crId in ywProject.srtCharacters:
            sortOrder += 1
            xmlCrt = ET.SubElement(characters, 'CHARACTER')
            build_character_subtree(xmlCrt, ywProject.characters[crId], sortOrder)

        #--- Process scenes.
        # Save the original XML scene subtrees
        # and remove them from the project tree.

        for xmlScn in scenes.findall('SCENE'):
            scId = xmlScn.find('ID').text
            xmlScenes[scId] = xmlScn
            scenes.remove(xmlScn)

        # Add the new XML scene subtrees to the project tree.

        for scId in ywProject.scenes:

            if not scId in xmlScenes:
                xmlScenes[scId] = ET.Element('SCENE')
                ET.SubElement(xmlScenes[scId], 'ID').text = scId

            build_scene_subtree(xmlScenes[scId], ywProject.scenes[scId])
            scenes.append(xmlScenes[scId])

        #--- Process chapters.
        # Save the original XML chapter subtree
        # and remove it from the project tree.

        for xmlChp in chapters.findall('CHAPTER'):
            chId = xmlChp.find('ID').text
            xmlChapters[chId] = xmlChp
            chapters.remove(xmlChp)

        # Add the new XML chapter subtrees to the project tree.

        sortOrder = 0

        for chId in ywProject.srtChapters:
            sortOrder += 1

            if not chId in xmlChapters:
                xmlChapters[chId] = ET.Element('CHAPTER')
                ET.SubElement(xmlChapters[chId], 'ID').text = chId

            build_chapter_subtree(xmlChapters[chId], ywProject.chapters[chId], sortOrder)

            chapters.append(xmlChapters[chId])

        indent(root)
        ywProject.tree = ET.ElementTree(root)

        # Write version-dependent scene contents to the xml element tree.

        return self.put_scene_contents(ywProject)

    def put_scene_contents(self, ywProject):
        """Modify the scene contents of an existing xml element tree.
        Return a message beginning with SUCCESS or ERROR.
        Strategy method for the yw7 file format variant.
        """

        root = ywProject.tree.getroot()

        for scn in root.iter('SCENE'):
            scId = scn.find('ID').text

            if ywProject.scenes[scId].sceneContent is not None:
                scn.find('SceneContent').text = ywProject.scenes[scId].sceneContent
                scn.find('WordCount').text = str(ywProject.scenes[scId].wordCount)
                scn.find('LetterCount').text = str(ywProject.scenes[scId].letterCount)

            try:
                scn.remove(scn.find('RTFFile'))

            except:
                pass

        return 'SUCCESS'



class Utf8TreeReader():
    """Read utf-8 encoded yWriter xml project file."""

    def read_element_tree(self, ywProject):
        """Parse the yWriter xml file located at filePath, fetching the Novel attributes.
        Return a message beginning with SUCCESS or ERROR.
        """

        try:
            ywProject.tree = ET.parse(ywProject.filePath)

        except:
            return 'ERROR: Can not process "' + os.path.normpath(ywProject.filePath) + '".'

        return 'SUCCESS: XML element tree read in.'



class Utf8TreeWriter():
    """Write utf-8 encoded yWriter project file."""

    def write_element_tree(self, ywProject):
        """Write back the xml element tree to a yWriter xml file located at filePath.
        Return a message beginning with SUCCESS or ERROR.
        """

        if os.path.isfile(ywProject.filePath):
            os.replace(ywProject.filePath, ywProject.filePath + '.bak')
            backedUp = True

        else:
            backedUp = False

        try:
            ywProject.tree.write(ywProject.filePath, xml_declaration=False, encoding='utf-8')

        except:

            if backedUp:
                os.replace(ywProject.filePath + '.bak', ywProject.filePath)

            return 'ERROR: Cannot write "' + os.path.normpath(ywProject.filePath) + '".'

        return 'SUCCESS'

from html import unescape


class Utf8Postprocessor():
    """Postprocess utf-8 encoded yWriter project."""

    def __init__(self):
        """Initialize instance variables."""
        self.cdataTags = ['Title', 'AuthorName', 'Bio', 'Desc',
                          'FieldTitle1', 'FieldTitle2', 'FieldTitle3',
                          'FieldTitle4', 'LaTeXHeaderFile', 'Tags',
                          'AKA', 'ImageFile', 'FullName', 'Goals',
                          'Notes', 'RTFFile', 'SceneContent',
                          'Outcome', 'Goal', 'Conflict']
        # Names of yWriter xml elements containing CDATA.
        # ElementTree.write omits CDATA tags, so they have to be inserted
        # afterwards.

    def format_xml(self, text):
        '''Postprocess the xml file created by ElementTree:
           Insert the missing CDATA tags,
           and replace xml entities by plain text.
        '''
        lines = text.split('\n')
        newlines = []

        for line in lines:

            for tag in self.cdataTags:
                line = re.sub('\<' + tag + '\>', '<' +
                              tag + '><![CDATA[', line)
                line = re.sub('\<\/' + tag + '\>',
                              ']]></' + tag + '>', line)

            newlines.append(line)

        text = '\n'.join(newlines)
        text = text.replace('[CDATA[ \n', '[CDATA[')
        text = text.replace('\n]]', ']]')
        text = unescape(text)

        return text

    def postprocess_xml_file(self, filePath):
        '''Postprocess the xml file created by ElementTree:
        Put a header on top, insert the missing CDATA tags,
        and replace xml entities by plain text.
        Return a message beginning with SUCCESS or ERROR.
        '''

        with open(filePath, 'r', encoding='utf-8') as f:
            text = f.read()

        text = self.format_xml(text)
        text = '<?xml version="1.0" encoding="utf-8"?>\n' + text

        try:

            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(text)

        except:
            return 'ERROR: Can not write "' + os.path.normpath(filePath) + '".'

        return 'SUCCESS: "' + os.path.normpath(filePath) + '" written.'



class Splitter():

    PART_SEPARATOR = '# '
    CHAPTER_SEPARATOR = '## '
    SCENE_SEPARATOR = '* * *'
    CLIP_TITLE = 20
    # This is used for splitting scenes.

    def split_scenes(self, ywPrj):
        """Generate new chapters and scenes if there are dividers within the scene content.
        """

        def create_chapter(chapterId, title, desc, level):
            """Create a new chapter and add it to the novel.
            """
            newChapter = Chapter()
            newChapter.title = title
            newChapter.desc = desc
            newChapter.chLevel = level
            newChapter.chType = 0
            ywPrj.chapters[chapterId] = newChapter

        def create_scene(sceneId, parent, splitCount):
            """Create a new scene and add it to the novel.
            """
            WARNING = ' (!) '

            newScene = Scene()

            if parent.title:

                if len(parent.title) > self.CLIP_TITLE:
                    title = parent.title[:self.CLIP_TITLE] + '...'

                else:
                    title = parent.title

                newScene.title = title + ' Split: ' + str(splitCount)

            else:
                newScene.title = 'New scene Split: ' + str(splitCount)

            if parent.desc and not parent.desc.startswith(WARNING):
                parent.desc = WARNING + parent.desc

            if parent.goal and not parent.goal.startswith(WARNING):
                parent.goal = WARNING + parent.goal

            if parent.conflict and not parent.conflict.startswith(WARNING):
                parent.conflict = WARNING + parent.conflict

            if parent.outcome and not parent.outcome.startswith(WARNING):
                parent.outcome = WARNING + parent.outcome

            # Reset the parent's status to Draft, if not Outline.

            if parent.status > 2:
                parent.status = 2

            newScene.status = parent.status
            newScene.isNotesScene = parent.isNotesScene
            newScene.isUnused = parent.isUnused
            newScene.isTodoScene = parent.isTodoScene
            newScene.date = parent.date
            newScene.time = parent.time
            newScene.day = parent.day
            newScene.hour = parent.hour
            newScene.minute = parent.minute
            newScene.lastsDays = parent.lastsDays
            newScene.lastsHours = parent.lastsHours
            newScene.lastsMinutes = parent.lastsMinutes
            ywPrj.scenes[sceneId] = newScene

        # Get the maximum chapter ID and scene ID.

        chIdMax = 0
        scIdMax = 0

        for chId in ywPrj.srtChapters:

            if int(chId) > chIdMax:
                chIdMax = int(chId)

        for scId in ywPrj.scenes:

            if int(scId) > scIdMax:
                scIdMax = int(scId)

        srtChapters = []

        for chId in ywPrj.srtChapters:
            srtChapters.append(chId)
            chapterId = chId
            srtScenes = []

            for scId in ywPrj.chapters[chId].srtScenes:
                srtScenes.append(scId)

                if not ywPrj.scenes[scId].sceneContent:
                    continue

                sceneId = scId
                lines = ywPrj.scenes[scId].sceneContent.split('\n')
                newLines = []
                inScene = True
                sceneSplitCount = 0

                # Search scene content for dividers.

                for line in lines:

                    if line.startswith(self.PART_SEPARATOR):

                        if inScene:
                            ywPrj.scenes[sceneId].sceneContent = '\n'.join(newLines)
                            newLines = []
                            sceneSplitCount = 0
                            inScene = False

                        ywPrj.chapters[chapterId].srtScenes = srtScenes
                        srtScenes = []

                        chIdMax += 1
                        chapterId = str(chIdMax)
                        create_chapter(chapterId, 'New part', line.replace(self.PART_SEPARATOR, ''), 1)
                        srtChapters.append(chapterId)

                    elif line.startswith(self.CHAPTER_SEPARATOR):

                        if inScene:
                            ywPrj.scenes[sceneId].sceneContent = '\n'.join(newLines)
                            newLines = []
                            sceneSplitCount = 0
                            inScene = False

                        ywPrj.chapters[chapterId].srtScenes = srtScenes
                        srtScenes = []

                        chIdMax += 1
                        chapterId = str(chIdMax)
                        create_chapter(chapterId, 'New chapter', line.replace(self.CHAPTER_SEPARATOR, ''), 0)
                        srtChapters.append(chapterId)

                    elif line.startswith(self.SCENE_SEPARATOR):
                        ywPrj.scenes[sceneId].sceneContent = '\n'.join(newLines)
                        newLines = []
                        sceneSplitCount += 1
                        scIdMax += 1
                        sceneId = str(scIdMax)
                        create_scene(sceneId, ywPrj.scenes[scId], sceneSplitCount)
                        srtScenes.append(sceneId)
                        inScene = True

                    elif not inScene:
                        newLines.append(line)
                        sceneSplitCount += 1
                        scIdMax += 1
                        sceneId = str(scIdMax)
                        create_scene(sceneId, ywPrj.scenes[scId], sceneSplitCount)
                        srtScenes.append(sceneId)
                        inScene = True

                    else:
                        newLines.append(line)

                ywPrj.scenes[sceneId].sceneContent = '\n'.join(newLines)

            ywPrj.chapters[chapterId].srtScenes = srtScenes

        ywPrj.srtChapters = srtChapters


class Yw7File(Novel):
    """yWriter 7 project file representation.

    Additional attributes:
        ywTreeReader -- strategy class to read yWriter project files.
        ywTreeBuilder -- strategy class to build an xml tree.
        ywTreeWriter -- strategy class to write yWriter project files.
        ywPostprocessor -- strategy class to postprocess yWriter project files.
        tree -- xml element tree of the yWriter project
    """

    DESCRIPTION = 'yWriter 7 project'
    EXTENSION = '.yw7'

    def __init__(self, filePath, **kwargs):
        """Initialize instance variables:
        Extend the superclass constructor by adding.
        """
        Novel.__init__(self, filePath)

        self.ywTreeReader = Utf8TreeReader()
        self.ywTreeBuilder = Yw7TreeBuilder()
        self.ywTreeWriter = Utf8TreeWriter()
        self.ywPostprocessor = Utf8Postprocessor()
        self.tree = None

    def _strip_spaces(self, lines):
        """Local helper method.

        Positional argument:
            lines -- list of strings

        Return lines with leading and trailing spaces removed.
        """
        stripped = []

        for line in lines:
            stripped.append(line.lstrip().rstrip())

        return stripped

    def read(self):
        """Parse the yWriter xml file, fetching the Novel attributes.
        Return a message beginning with SUCCESS or ERROR.
        Override the superclass method.
        """

        if self.is_locked():
            return 'ERROR: yWriter seems to be open. Please close first.'

        message = self.ywTreeReader.read_element_tree(self)

        if message.startswith('ERROR'):
            return message

        root = self.tree.getroot()

        #--- Read locations from the xml element tree.

        for loc in root.iter('LOCATION'):
            lcId = loc.find('ID').text
            self.srtLocations.append(lcId)
            self.locations[lcId] = WorldElement()

            if loc.find('Title') is not None:
                self.locations[lcId].title = loc.find('Title').text

            if loc.find('ImageFile') is not None:
                self.locations[lcId].image = loc.find('ImageFile').text

            if loc.find('Desc') is not None:
                self.locations[lcId].desc = loc.find('Desc').text

            if loc.find('AKA') is not None:
                self.locations[lcId].aka = loc.find('AKA').text

            if loc.find('Tags') is not None:

                if loc.find('Tags').text is not None:
                    tags = loc.find('Tags').text.split(';')
                    self.locations[lcId].tags = self._strip_spaces(tags)

        #--- Read items from the xml element tree.

        for itm in root.iter('ITEM'):
            itId = itm.find('ID').text
            self.srtItems.append(itId)
            self.items[itId] = WorldElement()

            if itm.find('Title') is not None:
                self.items[itId].title = itm.find('Title').text

            if itm.find('ImageFile') is not None:
                self.items[itId].image = itm.find('ImageFile').text

            if itm.find('Desc') is not None:
                self.items[itId].desc = itm.find('Desc').text

            if itm.find('AKA') is not None:
                self.items[itId].aka = itm.find('AKA').text

            if itm.find('Tags') is not None:

                if itm.find('Tags').text is not None:
                    tags = itm.find('Tags').text.split(';')
                    self.items[itId].tags = self._strip_spaces(tags)

        #--- Read characters from the xml element tree.

        for crt in root.iter('CHARACTER'):
            crId = crt.find('ID').text
            self.srtCharacters.append(crId)
            self.characters[crId] = Character()

            if crt.find('Title') is not None:
                self.characters[crId].title = crt.find('Title').text

            if crt.find('ImageFile') is not None:
                self.characters[crId].image = crt.find('ImageFile').text

            if crt.find('Desc') is not None:
                self.characters[crId].desc = crt.find('Desc').text

            if crt.find('AKA') is not None:
                self.characters[crId].aka = crt.find('AKA').text

            if crt.find('Tags') is not None:

                if crt.find('Tags').text is not None:
                    tags = crt.find('Tags').text.split(';')
                    self.characters[crId].tags = self._strip_spaces(tags)

            if crt.find('Notes') is not None:
                self.characters[crId].notes = crt.find('Notes').text

            if crt.find('Bio') is not None:
                self.characters[crId].bio = crt.find('Bio').text

            if crt.find('Goals') is not None:
                self.characters[crId].goals = crt.find('Goals').text

            if crt.find('FullName') is not None:
                self.characters[crId].fullName = crt.find('FullName').text

            if crt.find('Major') is not None:
                self.characters[crId].isMajor = True

            else:
                self.characters[crId].isMajor = False

        #--- Read attributes at novel level from the xml element tree.

        prj = root.find('PROJECT')

        if prj.find('Title') is not None:
            self.title = prj.find('Title').text

        if prj.find('AuthorName') is not None:
            self.author = prj.find('AuthorName').text

        if prj.find('Desc') is not None:
            self.desc = prj.find('Desc').text

        if prj.find('FieldTitle1') is not None:
            self.fieldTitle1 = prj.find('FieldTitle1').text

        if prj.find('FieldTitle2') is not None:
            self.fieldTitle2 = prj.find('FieldTitle2').text

        if prj.find('FieldTitle3') is not None:
            self.fieldTitle3 = prj.find('FieldTitle3').text

        if prj.find('FieldTitle4') is not None:
            self.fieldTitle4 = prj.find('FieldTitle4').text

        #--- Read attributes at chapter level from the xml element tree.

        self.srtChapters = []
        # This is necessary for re-reading.

        for chp in root.iter('CHAPTER'):
            chId = chp.find('ID').text
            self.chapters[chId] = Chapter()
            self.srtChapters.append(chId)

            if chp.find('Title') is not None:
                self.chapters[chId].title = chp.find('Title').text

            if chp.find('Desc') is not None:
                self.chapters[chId].desc = chp.find('Desc').text

            if chp.find('SectionStart') is not None:
                self.chapters[chId].chLevel = 1

            else:
                self.chapters[chId].chLevel = 0

            if chp.find('Type') is not None:
                self.chapters[chId].oldType = int(chp.find('Type').text)

            if chp.find('ChapterType') is not None:
                self.chapters[chId].chType = int(chp.find('ChapterType').text)

            if chp.find('Unused') is not None:
                self.chapters[chId].isUnused = True

            else:
                self.chapters[chId].isUnused = False

            self.chapters[chId].suppressChapterTitle = False

            if self.chapters[chId].title is not None:

                if self.chapters[chId].title.startswith('@'):
                    self.chapters[chId].suppressChapterTitle = True

            for chFields in chp.findall('Fields'):

                if chFields.find('Field_SuppressChapterTitle') is not None:

                    if chFields.find('Field_SuppressChapterTitle').text == '1':
                        self.chapters[chId].suppressChapterTitle = True

                if chFields.find('Field_IsTrash') is not None:

                    if chFields.find('Field_IsTrash').text == '1':
                        self.chapters[chId].isTrash = True

                    else:
                        self.chapters[chId].isTrash = False

                if chFields.find('Field_SuppressChapterBreak') is not None:

                    if chFields.find('Field_SuppressChapterBreak').text == '1':
                        self.chapters[chId].suppressChapterBreak = True

                    else:
                        self.chapters[chId].suppressChapterBreak = False

                else:
                    self.chapters[chId].suppressChapterBreak = False

            self.chapters[chId].srtScenes = []

            if chp.find('Scenes') is not None:

                if not self.chapters[chId].isTrash:

                    for scn in chp.find('Scenes').findall('ScID'):
                        scId = scn.text
                        self.chapters[chId].srtScenes.append(scId)

        #--- Read attributes at scene level from the xml element tree.

        for scn in root.iter('SCENE'):
            scId = scn.find('ID').text
            self.scenes[scId] = Scene()

            if scn.find('Title') is not None:
                self.scenes[scId].title = scn.find('Title').text

            if scn.find('Desc') is not None:
                self.scenes[scId].desc = scn.find('Desc').text

            if scn.find('RTFFile') is not None:
                self.scenes[scId].rtfFile = scn.find('RTFFile').text

            # This is relevant for yW5 files with no SceneContent:

            if scn.find('WordCount') is not None:
                self.scenes[scId].wordCount = int(
                    scn.find('WordCount').text)

            if scn.find('LetterCount') is not None:
                self.scenes[scId].letterCount = int(
                    scn.find('LetterCount').text)

            if scn.find('SceneContent') is not None:
                sceneContent = scn.find('SceneContent').text

                if sceneContent is not None:
                    self.scenes[scId].sceneContent = sceneContent

            if scn.find('Unused') is not None:
                self.scenes[scId].isUnused = True

            else:
                self.scenes[scId].isUnused = False

            self.scenes[scId].isNotesScene = False
            self.scenes[scId].isTodoScene = False

            for scFields in scn.findall('Fields'):

                if scFields.find('Field_SceneType') is not None:

                    if scFields.find('Field_SceneType').text == '1':
                        self.scenes[scId].isNotesScene = True

                    if scFields.find('Field_SceneType').text == '2':
                        self.scenes[scId].isTodoScene = True

            if scn.find('ExportCondSpecific') is None:
                self.scenes[scId].doNotExport = False

            elif scn.find('ExportWhenRTF') is not None:
                self.scenes[scId].doNotExport = False

            else:
                self.scenes[scId].doNotExport = True

            if scn.find('Status') is not None:
                self.scenes[scId].status = int(scn.find('Status').text)

            if scn.find('Notes') is not None:
                self.scenes[scId].sceneNotes = scn.find('Notes').text

            if scn.find('Tags') is not None:

                if scn.find('Tags').text is not None:
                    tags = scn.find('Tags').text.split(';')
                    self.scenes[scId].tags = self._strip_spaces(tags)

            if scn.find('Field1') is not None:
                self.scenes[scId].field1 = scn.find('Field1').text

            if scn.find('Field2') is not None:
                self.scenes[scId].field2 = scn.find('Field2').text

            if scn.find('Field3') is not None:
                self.scenes[scId].field3 = scn.find('Field3').text

            if scn.find('Field4') is not None:
                self.scenes[scId].field4 = scn.find('Field4').text

            if scn.find('AppendToPrev') is not None:
                self.scenes[scId].appendToPrev = True

            else:
                self.scenes[scId].appendToPrev = False

            if scn.find('SpecificDateTime') is not None:
                dateTime = scn.find('SpecificDateTime').text.split(' ')

                for dt in dateTime:

                    if '-' in dt:
                        self.scenes[scId].date = dt

                    elif ':' in dt:
                        self.scenes[scId].time = dt

            else:
                if scn.find('Day') is not None:
                    self.scenes[scId].day = scn.find('Day').text

                if scn.find('Hour') is not None:
                    self.scenes[scId].hour = scn.find('Hour').text

                if scn.find('Minute') is not None:
                    self.scenes[scId].minute = scn.find('Minute').text

            if scn.find('LastsDays') is not None:
                self.scenes[scId].lastsDays = scn.find('LastsDays').text

            if scn.find('LastsHours') is not None:
                self.scenes[scId].lastsHours = scn.find('LastsHours').text

            if scn.find('LastsMinutes') is not None:
                self.scenes[scId].lastsMinutes = scn.find('LastsMinutes').text

            if scn.find('ReactionScene') is not None:
                self.scenes[scId].isReactionScene = True

            else:
                self.scenes[scId].isReactionScene = False

            if scn.find('SubPlot') is not None:
                self.scenes[scId].isSubPlot = True

            else:
                self.scenes[scId].isSubPlot = False

            if scn.find('Goal') is not None:
                self.scenes[scId].goal = scn.find('Goal').text

            if scn.find('Conflict') is not None:
                self.scenes[scId].conflict = scn.find('Conflict').text

            if scn.find('Outcome') is not None:
                self.scenes[scId].outcome = scn.find('Outcome').text

            if scn.find('ImageFile') is not None:
                self.scenes[scId].image = scn.find('ImageFile').text

            if scn.find('Characters') is not None:
                for crId in scn.find('Characters').iter('CharID'):

                    if self.scenes[scId].characters is None:
                        self.scenes[scId].characters = []

                    self.scenes[scId].characters.append(crId.text)

            if scn.find('Locations') is not None:
                for lcId in scn.find('Locations').iter('LocID'):

                    if self.scenes[scId].locations is None:
                        self.scenes[scId].locations = []

                    self.scenes[scId].locations.append(lcId.text)

            if scn.find('Items') is not None:
                for itId in scn.find('Items').iter('ItemID'):

                    if self.scenes[scId].items is None:
                        self.scenes[scId].items = []

                    self.scenes[scId].items.append(itId.text)

        # Make sure that ToDo, Notes, and Unused type is inherited from the
        # chapter.

        for chId in self.chapters:

            if self.chapters[chId].chType == 2:
                # Chapter is "ToDo" type.

                for scId in self.chapters[chId].srtScenes:
                    self.scenes[scId].isTodoScene = True
                    self.scenes[scId].isUnused = True

            elif self.chapters[chId].chType == 1:
                # Chapter is "Notes" type.

                for scId in self.chapters[chId].srtScenes:
                    self.scenes[scId].isNotesScene = True
                    self.scenes[scId].isUnused = True

            elif self.chapters[chId].isUnused:

                for scId in self.chapters[chId].srtScenes:
                    self.scenes[scId].isUnused = True

        return 'SUCCESS: ' + str(len(self.scenes)) + ' Scenes read from "' + os.path.normpath(self.filePath) + '".'

    def merge(self, source):
        """Copy required attributes of the source object.
        Return a message beginning with SUCCESS or ERROR.
        Override the superclass method.
        """

        def merge_lists(srcLst, tgtLst):
            """Insert srcLst items to tgtLst, if missing.
            """
            j = 0

            for i in range(len(srcLst)):

                if not srcLst[i] in tgtLst:
                    tgtLst.insert(j, srcLst[i])
                    j += 1

                else:
                    j = tgtLst.index(srcLst[i]) + 1

        if os.path.isfile(self.filePath):
            message = self.read()
            # initialize data

            if message.startswith('ERROR'):
                return message

        #--- Merge and re-order locations.

        if source.srtLocations != []:
            self.srtLocations = source.srtLocations
            temploc = self.locations
            self.locations = {}

            for lcId in source.srtLocations:

                # Build a new self.locations dictionary sorted like the
                # source

                self.locations[lcId] = WorldElement()

                if not lcId in temploc:
                    # A new location has been added
                    temploc[lcId] = WorldElement()

                if source.locations[lcId].title:
                    # avoids deleting the title, if it is empty by accident
                    self.locations[lcId].title = source.locations[lcId].title

                else:
                    self.locations[lcId].title = temploc[lcId].title

                if source.locations[lcId].image is not None:
                    self.locations[lcId].image = source.locations[lcId].image

                else:
                    self.locations[lcId].desc = temploc[lcId].desc

                if source.locations[lcId].desc is not None:
                    self.locations[lcId].desc = source.locations[lcId].desc

                else:
                    self.locations[lcId].desc = temploc[lcId].desc

                if source.locations[lcId].aka is not None:
                    self.locations[lcId].aka = source.locations[lcId].aka

                else:
                    self.locations[lcId].aka = temploc[lcId].aka

                if source.locations[lcId].tags is not None:
                    self.locations[lcId].tags = source.locations[lcId].tags

                else:
                    self.locations[lcId].tags = temploc[lcId].tags

        #--- Merge and re-order items.

        if source.srtItems != []:
            self.srtItems = source.srtItems
            tempitm = self.items
            self.items = {}

            for itId in source.srtItems:

                # Build a new self.items dictionary sorted like the
                # source

                self.items[itId] = WorldElement()

                if not itId in tempitm:
                    # A new item has been added
                    tempitm[itId] = WorldElement()

                if source.items[itId].title:
                    # avoids deleting the title, if it is empty by accident
                    self.items[itId].title = source.items[itId].title

                else:
                    self.items[itId].title = tempitm[itId].title

                if source.items[itId].image is not None:
                    self.items[itId].image = source.items[itId].image

                else:
                    self.items[itId].image = tempitm[itId].image

                if source.items[itId].desc is not None:
                    self.items[itId].desc = source.items[itId].desc

                else:
                    self.items[itId].desc = tempitm[itId].desc

                if source.items[itId].aka is not None:
                    self.items[itId].aka = source.items[itId].aka

                else:
                    self.items[itId].aka = tempitm[itId].aka

                if source.items[itId].tags is not None:
                    self.items[itId].tags = source.items[itId].tags

                else:
                    self.items[itId].tags = tempitm[itId].tags

        #--- Merge and re-order characters.

        if source.srtCharacters != []:
            self.srtCharacters = source.srtCharacters
            tempchr = self.characters
            self.characters = {}

            for crId in source.srtCharacters:

                # Build a new self.characters dictionary sorted like the
                # source

                self.characters[crId] = Character()

                if not crId in tempchr:
                    # A new character has been added
                    tempchr[crId] = Character()

                if source.characters[crId].title:
                    # avoids deleting the title, if it is empty by accident
                    self.characters[crId].title = source.characters[crId].title

                else:
                    self.characters[crId].title = tempchr[crId].title

                if source.characters[crId].image is not None:
                    self.characters[crId].image = source.characters[crId].image

                else:
                    self.characters[crId].image = tempchr[crId].image

                if source.characters[crId].desc is not None:
                    self.characters[crId].desc = source.characters[crId].desc

                else:
                    self.characters[crId].desc = tempchr[crId].desc

                if source.characters[crId].aka is not None:
                    self.characters[crId].aka = source.characters[crId].aka

                else:
                    self.characters[crId].aka = tempchr[crId].aka

                if source.characters[crId].tags is not None:
                    self.characters[crId].tags = source.characters[crId].tags

                else:
                    self.characters[crId].tags = tempchr[crId].tags

                if source.characters[crId].notes is not None:
                    self.characters[crId].notes = source.characters[crId].notes

                else:
                    self.characters[crId].notes = tempchr[crId].notes

                if source.characters[crId].bio is not None:
                    self.characters[crId].bio = source.characters[crId].bio

                else:
                    self.characters[crId].bio = tempchr[crId].bio

                if source.characters[crId].goals is not None:
                    self.characters[crId].goals = source.characters[crId].goals

                else:
                    self.characters[crId].goals = tempchr[crId].goals

                if source.characters[crId].fullName is not None:
                    self.characters[crId].fullName = source.characters[crId].fullName

                else:
                    self.characters[crId].fullName = tempchr[crId].fullName

                if source.characters[crId].isMajor is not None:
                    self.characters[crId].isMajor = source.characters[crId].isMajor

                else:
                    self.characters[crId].isMajor = tempchr[crId].isMajor

        #--- Merge scenes.

        sourceHasSceneContent = False

        for scId in source.scenes:

            if not scId in self.scenes:
                self.scenes[scId] = Scene()

            if source.scenes[scId].title:
                # avoids deleting the title, if it is empty by accident
                self.scenes[scId].title = source.scenes[scId].title

            if source.scenes[scId].desc is not None:
                self.scenes[scId].desc = source.scenes[scId].desc

            if source.scenes[scId].sceneContent is not None:
                self.scenes[scId].sceneContent = source.scenes[scId].sceneContent
                sourceHasSceneContent = True

            if source.scenes[scId].isUnused is not None:
                self.scenes[scId].isUnused = source.scenes[scId].isUnused

            if source.scenes[scId].isNotesScene is not None:
                self.scenes[scId].isNotesScene = source.scenes[scId].isNotesScene

            if source.scenes[scId].isTodoScene is not None:
                self.scenes[scId].isTodoScene = source.scenes[scId].isTodoScene

            if source.scenes[scId].status is not None:
                self.scenes[scId].status = source.scenes[scId].status

            if source.scenes[scId].sceneNotes is not None:
                self.scenes[scId].sceneNotes = source.scenes[scId].sceneNotes

            if source.scenes[scId].tags is not None:
                self.scenes[scId].tags = source.scenes[scId].tags

            if source.scenes[scId].field1 is not None:
                self.scenes[scId].field1 = source.scenes[scId].field1

            if source.scenes[scId].field2 is not None:
                self.scenes[scId].field2 = source.scenes[scId].field2

            if source.scenes[scId].field3 is not None:
                self.scenes[scId].field3 = source.scenes[scId].field3

            if source.scenes[scId].field4 is not None:
                self.scenes[scId].field4 = source.scenes[scId].field4

            if source.scenes[scId].appendToPrev is not None:
                self.scenes[scId].appendToPrev = source.scenes[scId].appendToPrev

            if source.scenes[scId].date or source.scenes[scId].time:

                if source.scenes[scId].date is not None:
                    self.scenes[scId].date = source.scenes[scId].date

                if source.scenes[scId].time is not None:
                    self.scenes[scId].time = source.scenes[scId].time

            elif source.scenes[scId].minute or source.scenes[scId].hour or source.scenes[scId].day:
                self.scenes[scId].date = None
                self.scenes[scId].time = None

            if source.scenes[scId].minute is not None:
                self.scenes[scId].minute = source.scenes[scId].minute

            if source.scenes[scId].hour is not None:
                self.scenes[scId].hour = source.scenes[scId].hour

            if source.scenes[scId].day is not None:
                self.scenes[scId].day = source.scenes[scId].day

            if source.scenes[scId].lastsMinutes is not None:
                self.scenes[scId].lastsMinutes = source.scenes[scId].lastsMinutes

            if source.scenes[scId].lastsHours is not None:
                self.scenes[scId].lastsHours = source.scenes[scId].lastsHours

            if source.scenes[scId].lastsDays is not None:
                self.scenes[scId].lastsDays = source.scenes[scId].lastsDays

            if source.scenes[scId].isReactionScene is not None:
                self.scenes[scId].isReactionScene = source.scenes[scId].isReactionScene

            if source.scenes[scId].isSubPlot is not None:
                self.scenes[scId].isSubPlot = source.scenes[scId].isSubPlot

            if source.scenes[scId].goal is not None:
                self.scenes[scId].goal = source.scenes[scId].goal

            if source.scenes[scId].conflict is not None:
                self.scenes[scId].conflict = source.scenes[scId].conflict

            if source.scenes[scId].outcome is not None:
                self.scenes[scId].outcome = source.scenes[scId].outcome

            if source.scenes[scId].characters is not None:
                self.scenes[scId].characters = []

                for crId in source.scenes[scId].characters:

                    if crId in self.characters:
                        self.scenes[scId].characters.append(crId)

            if source.scenes[scId].locations is not None:
                self.scenes[scId].locations = []

                for lcId in source.scenes[scId].locations:

                    if lcId in self.locations:
                        self.scenes[scId].locations.append(lcId)

            if source.scenes[scId].items is not None:
                self.scenes[scId].items = []

                for itId in source.scenes[scId].items:

                    if itId in self.items:
                        self.scenes[scId].items.append(itId)

        #--- Merge chapters.

        for chId in source.chapters:

            if not chId in self.chapters:
                self.chapters[chId] = Chapter()

            if source.chapters[chId].title:
                # avoids deleting the title, if it is empty by accident
                self.chapters[chId].title = source.chapters[chId].title

            if source.chapters[chId].desc is not None:
                self.chapters[chId].desc = source.chapters[chId].desc

            if source.chapters[chId].chLevel is not None:
                self.chapters[chId].chLevel = source.chapters[chId].chLevel

            if source.chapters[chId].oldType is not None:
                self.chapters[chId].oldType = source.chapters[chId].oldType

            if source.chapters[chId].chType is not None:
                self.chapters[chId].chType = source.chapters[chId].chType

            if source.chapters[chId].isUnused is not None:
                self.chapters[chId].isUnused = source.chapters[chId].isUnused

            if source.chapters[chId].suppressChapterTitle is not None:
                self.chapters[chId].suppressChapterTitle = source.chapters[chId].suppressChapterTitle

            if source.chapters[chId].suppressChapterBreak is not None:
                self.chapters[chId].suppressChapterBreak = source.chapters[chId].suppressChapterBreak

            if source.chapters[chId].isTrash is not None:
                self.chapters[chId].isTrash = source.chapters[chId].isTrash

            #--- Merge the chapter's scene list.
            # New scenes may be added.
            # Existing scenes may be moved to another chapter.
            # Deletion of scenes is not considered.
            # The scene's sort order may not change.

            if source.chapters[chId].srtScenes is not None:

                # Remove scenes that have been moved to another chapter from the scene list.

                srtScenes = []

                for scId in self.chapters[chId].srtScenes:

                    if scId in source.chapters[chId].srtScenes or not scId in source.scenes:
                        srtScenes.append(scId)
                        # The scene has not moved to another chapter or isn't imported

                    self.chapters[chId].srtScenes = srtScenes

                # Add new or moved scenes to the scene list.

                merge_lists(source.chapters[chId].srtScenes, self.chapters[chId].srtScenes)

        #--- Merge project attributes.

        if source.title:
            # avoids deleting the title, if it is empty by accident
            self.title = source.title

        if source.desc is not None:
            self.desc = source.desc

        if source.author is not None:
            self.author = source.author

        if source.fieldTitle1 is not None:
            self.fieldTitle1 = source.fieldTitle1

        if source.fieldTitle2 is not None:
            self.fieldTitle2 = source.fieldTitle2

        if source.fieldTitle3 is not None:
            self.fieldTitle3 = source.fieldTitle3

        if source.fieldTitle4 is not None:
            self.fieldTitle4 = source.fieldTitle4

        # Add new chapters to the chapter list.
        # Deletion of chapters is not considered.
        # The sort order of chapters may not change.

        merge_lists(source.srtChapters, self.srtChapters)

        # Split scenes by inserted part/chapter/scene dividers.
        # This must be done after regular merging
        # in order to avoid creating duplicate IDs.

        if sourceHasSceneContent:
            sceneSplitter = Splitter()
            sceneSplitter.split_scenes(self)

        return 'SUCCESS'

    def write(self):
        """Open the yWriter xml file located at filePath and 
        replace a set of attributes not being None.
        Return a message beginning with SUCCESS or ERROR.
        Override the superclass method.
        """

        if self.is_locked():
            return 'ERROR: yWriter seems to be open. Please close first.'

        message = self.ywTreeBuilder.build_element_tree(self)

        if message.startswith('ERROR'):
            return message

        message = self.ywTreeWriter.write_element_tree(self)

        if message.startswith('ERROR'):
            return message

        return self.ywPostprocessor.postprocess_xml_file(self.filePath)

    def is_locked(self):
        """Return True if a .lock file placed by yWriter exists.
        Otherwise, return False. 
        """
        return os.path.isfile(self.filePath + '.lock')
from datetime import datetime


from hashlib import pbkdf2_hmac


class Handles():
    """Hold a list of novelWriter compatible handles.
    The only purpose of this list is to use unique handles.
    Therefore, it is not intended to delete members.
    """
    HANDLE_CHARS = list('abcdef0123456789')
    SIZE = 13

    def __init__(self):
        self._handles = []

    def has_member(self, handle):
        """Return True if handle is in the list.
        """
        return handle in self._handles

    def add_member(self, handle):
        """Add handle to the list, if unique and compliant.
        Return True on success.
        Return False if handle is not accepted for any reason.
        """
        if self.has_member(handle):
            return False

        if len(handle) != self.SIZE:
            return False

        for c in handle:

            if not c in self.HANDLE_CHARS:
                return False

        self._handles.append(handle)
        return True

    def create_member(self, text):
        """Create a create_member handle derived from text and add_member it to the list.
        Return the handle.
        Use a non-random algorithm in order to faciliate testing.
        """

        def create_handle(text, salt):
            """Return a handle for novelWriter.
            """
            text = text.encode('utf-8')
            key = pbkdf2_hmac('sha1', text, bytes(salt), 1)
            keyInt = int.from_bytes(key, byteorder='big')
            handle = ''

            while len(handle) < self.SIZE and keyInt > 0:
                handle += self.HANDLE_CHARS[keyInt % len(self.HANDLE_CHARS)]
                keyInt //= len(self.HANDLE_CHARS)

            return handle

        i = 0
        handle = create_handle(text, i)

        while not self.add_member(handle):
            i += 1

            if i > 1000:
                raise ValueError('Unable to create a proper handle.')

            handle = create_handle(text, i)

        return(handle)


class NwItem():
    """novelWriter item representation."""

    def __init__(self):
        self.nwName = None
        self.nwType = None
        self.nwClass = None
        self.nwStatus = None
        self.nwExported = None
        self.nwLayout = None
        self.nwCharCount = None
        self.nwWordCount = None
        self.nwParaCount = None
        self.nwCursorPos = None

        self.nwHandle = None
        self.nwOrder = None
        self.nwParent = None

    def read(self, node):
        """Read a novelWriter node entry from the XML project tree. 
        Return the handle.
        """
        self.nwHandle = node.attrib.get('handle')
        self.nwOrder = int(node.attrib.get('order'))
        self.nwParent = node.attrib.get('parent')

        if node.find('name') is not None:
            self.nwName = node.find('name').text

        if node.find('type') is not None:
            self.nwType = node.find('type').text

        if node.find('class') is not None:
            self.nwClass = node.find('class').text

        if node.find('status') is not None:
            self.nwStatus = node.find('status').text

        if node.find('exported') is not None:
            self.nwExported = node.find('exported').text

        if node.find('layout') is not None:
            self.nwLayout = node.find('layout').text

        return self.nwHandle

    def write(self, parentNode):
        """Write a novelWriter item entry to the XML project tree.
        """
        attrs = {
            'handle': self.nwHandle,
            'order': str(self.nwOrder),
            'parent': self.nwParent
        }
        node = ET.SubElement(parentNode, 'item', attrs)

        if self.nwName is not None:
            ET.SubElement(node, 'name').text = self.nwName

        if self.nwType is not None:
            ET.SubElement(node, 'type').text = self.nwType

        if self.nwClass is not None:
            ET.SubElement(node, 'class').text = self.nwClass

        if self.nwStatus is not None:
            ET.SubElement(node, 'status').text = self.nwStatus

        if self.nwExported is not None:
            ET.SubElement(node, 'exported').text = self.nwExported

        if self.nwLayout is not None:
            ET.SubElement(node, 'layout').text = self.nwLayout

        if self.nwCharCount is not None:
            ET.SubElement(node, 'charCount').text = self.nwCharCount

        if self.nwWordCount is not None:
            ET.SubElement(node, 'wordCount').text = self.nwWordCount

        if self.nwParaCount is not None:
            ET.SubElement(node, 'paraCount').text = self.nwParaCount

        if self.nwCursorPos is not None:
            ET.SubElement(node, 'cursorPos').text = self.nwCursorPos

        return node




class NwdFile():
    """novelWriter item file representation.
    """

    EXTENSION = '.nwd'

    def __init__(self, prj, nwItem):
        """Define instance variables.
        """
        self.lines = None
        self.prj = prj
        self.nwItem = nwItem
        self.filePath = os.path.dirname(self.prj.filePath) + self.prj.CONTENT_DIR + nwItem.nwHandle + self.EXTENSION
        self.lines = []

    def read(self):
        """Read a content file. 
        Return a message beginning with SUCCESS or ERROR.
        """

        try:
            with open(self.filePath, 'r', encoding='utf-8') as f:
                self.lines = f.read().split('\n')

            return 'SUCCESS'

        except:
            return 'ERROR: Can not read "' + os.path.normpath(self.filePath) + '".'

    def write(self):
        """Write a content file. 
        Return a message beginning with SUCCESS or ERROR.
        """
        lines = ['%%~name: ' + self.nwItem.nwName,
                 '%%~path: ' + self.nwItem.nwParent + '/' + self.nwItem.nwHandle,
                 '%%~kind: ' + self.nwItem.nwClass + '/' + self.nwItem.nwLayout,
                 ]
        lines.extend(self.lines)
        text = '\n'.join(lines)

        try:
            with open(self.filePath, 'w', encoding='utf-8') as f:
                f.write(text)

            return 'SUCCESS'

        except:
            return 'ERROR: Can not write "' + os.path.normpath(self.filePath) + '".'


class NwdCharacterFile(NwdFile):
    """novelWriter character file representation.
    """

    def __init__(self, prj, nwItem):
        """Extend the superclass constructor,
        defining instance variables.
        """
        NwdFile.__init__(self, prj, nwItem)

        # Customizable Character importance.

        self.majorCharacterStatus = prj.kwargs['major_character_status']

        # Headings that divide the character sheet into sections.

        self.characterNotesHeading = prj.kwargs['character_notes_heading']
        self.characterGoalsHeading = prj.kwargs['character_goals_heading']
        self.characterBioHeading = prj.kwargs['character_bio_heading']

        # Customizable tags for characters and locations.

        self.weAkaTag = '%' + prj.kwargs['world_element_aka_tag'] + ':'
        self.weTagTag = '%' + prj.kwargs['world_element_tag_tag'] + ':'

    def read(self):
        """Parse the files and store selected properties.
        Return a message beginning with SUCCESS or ERROR.
        Extend the superclass method.
        """
        message = NwdFile.read(self)

        if message.startswith('ERROR'):
            return message

        self.prj.crCount += 1
        crId = str(self.prj.crCount)
        self.prj.characters[crId] = Character()
        self.prj.characters[crId].fullName = self.nwItem.nwName
        self.prj.characters[crId].title = self.nwItem.nwName
        desc = []
        bio = []
        goals = []
        notes = []

        section = 'desc'

        for line in self.lines:

            if line == '':
                continue

            elif line.startswith('%%'):
                continue

            elif line.startswith('#'):
                section = 'desc'

                if line.startswith(self.characterBioHeading):
                    section = 'bio'

                elif line.startswith(self.characterGoalsHeading):
                    section = 'goals'

                elif line.startswith(self.characterNotesHeading):
                    section = 'notes'

            elif line.startswith('@'):

                if line.startswith('@tag'):
                    self.prj.characters[crId].title = line.split(':')[1].strip()

            elif line.startswith('%'):

                if line.startswith(self.weAkaTag):
                    self.prj.characters[crId].aka = line.split(':')[1].strip()

                elif line.startswith(self.weTagTag):

                    if self.prj.characters[crId].tags is None:
                        self.prj.characters[crId].tags = []

                    self.prj.characters[crId].tags.append(line.split(':')[1].strip())

            elif section == 'desc':
                desc.append(line)

            elif section == 'bio':
                bio.append(line)

            elif section == 'goals':
                goals.append(line)

            elif section == 'notes':
                notes.append(line)

        self.prj.characters[crId].desc = '\n'.join(desc)
        self.prj.characters[crId].bio = '\n'.join(bio)
        self.prj.characters[crId].goals = '\n'.join(goals)
        self.prj.characters[crId].notes = '\n'.join(notes)

        if self.nwItem.nwStatus in self.majorCharacterStatus:
            self.prj.characters[crId].isMajor = True

        else:
            self.prj.characters[crId].isMajor = False

        self.prj.crIdsByTitle[self.prj.characters[crId].title] = [crId]
        self.prj.srtCharacters.append(crId)

        return('SUCCESS')



class NwdWorldFile(NwdFile):
    """novelWriter character file representation.
    """

    def __init__(self, prj, nwItem):
        """Extend the superclass constructor,
        defining instance variables.
        """
        NwdFile.__init__(self, prj, nwItem)

        # Customizable tags for characters and locations.

        self.weAkaTag = '%' + prj.kwargs['world_element_aka_tag'] + ':'
        self.weTagTag = '%' + prj.kwargs['world_element_tag_tag'] + ':'

    def read(self):
        """Parse the files and store selected properties.
        Return a message beginning with SUCCESS or ERROR.
        Extend the superclass method.
        """

        self.prj.lcCount = 0
        self.prj.lcIdsByName = {}

        #--- Get locations.

        message = NwdFile.read(self)

        if message.startswith('ERROR'):
            return message

        self.prj.lcCount += 1
        lcId = str(self.prj.lcCount)
        self.prj.locations[lcId] = WorldElement()
        self.prj.locations[lcId].title = self.nwItem.nwName
        desc = []

        for line in self.lines:

            if line == '':
                continue

            elif line.startswith('%%'):
                continue

            elif line.startswith('#'):
                continue

            elif line.startswith('%'):

                if line.startswith(self.weAkaTag):
                    self.prj.locations[lcId].aka = line.split(':')[1].strip()

                elif line.startswith(self.weTagTag):

                    if self.prj.locations[lcId].tags is None:
                        self.prj.locations[lcId].tags = []

                    self.prj.locations[lcId].tags.append(line.split(':')[1].strip())

            elif line.startswith('@'):

                if line.startswith('@tag'):
                    self.prj.locations[lcId].title = line.split(':')[1].strip()

            else:
                desc.append(line)

        self.prj.locations[lcId].desc = '\n'.join(desc)
        self.prj.lcIdsByName[self.prj.locations[lcId].title] = [lcId]
        self.prj.srtLocations.append(lcId)
        return('SUCCESS')




class NwdNovelFile(NwdFile):
    """novelWriter novel file representation.
    """

    def __init__(self, prj, nwItem):
        """Extend the superclass constructor,
        defining instance variables.
        """
        NwdFile.__init__(self, prj, nwItem)

        # Scene status mapping.

        self.outlineStatus = prj.kwargs['outline_status']
        self.draftStatus = prj.kwargs['draft_status']
        self.firstEditStatus = prj.kwargs['first_edit_status']
        self.secondEditStatus = prj.kwargs['second_edit_status']
        self.doneStatus = prj.kwargs['done_status']

        # Headings that divide the file into parts, chapters and scenes.

        # self.partHeadingPrefix = prj.kwargs['part_heading_prefix']
        # self.chapterHeadingPrefix = prj.kwargs['chapter_heading_prefix']
        # self.sceneHeadingPrefix = prj.kwargs['scene_heading_prefix']
        # self.sectionHeadingPrefix = prj.kwargs['section_heading_prefix']

    def read(self):
        """Parse the files and store selected properties.
        Return a message beginning with SUCCESS or ERROR.
        Extend the superclass method.
        """

        def write_scene_content(scId, contentLines):

            if scId is not None:
                text = '\n'.join(contentLines)
                self.prj.scenes[scId].sceneContent = text

        #--- Get chapters and scenes.

        scId = None

        message = NwdFile.read(self)

        if message.startswith('ERROR'):
            return message

        # Determine the attibutes for all chapters and scenes included.

        chType = None
        isUnused = None
        isNotesScene = None
        status = None
        title = None

        if self.nwItem.nwLayout == 'DOCUMENT':
            chType = 0
            # Normal

        elif self.nwItem.nwLayout == 'NOTE':
            chType = 1
            # Notes
            isNotesScene = True

        else:
            isUnused = True

        if self.nwItem.nwStatus in self.outlineStatus:
            status = 1

        elif self.nwItem.nwStatus in self.draftStatus:
            status = 2

        elif self.nwItem.nwStatus in self.firstEditStatus:
            status = 3

        elif self.nwItem.nwStatus in self.secondEditStatus:
            status = 4

        elif self.nwItem.nwStatus in self.doneEditStatus:
            status = 5

        contentLines = []

        for line in self.lines:

            if line.startswith('%%'):
                continue

            elif line.startswith('@'):
                continue

            elif line.startswith('%'):
                continue

            elif line.startswith('###') and self.prj.chId:

                # Write previous scene.

                write_scene_content(scId, contentLines)
                scId = None

                self.prj.scCount += 1
                scId = str(self.prj.scCount)
                self.prj.scenes[scId] = Scene()
                self.prj.scenes[scId].status = status
                title = line.split(' ', maxsplit=1)[1]
                self.prj.scenes[scId].title = title
                self.prj.scenes[scId].isNotesScene = isNotesScene
                self.prj.chapters[self.prj.chId].srtScenes.append(scId)
                contentLines = [line]

                if line.startswith('####'):
                    self.prj.scenes[scId].appendToPrev = True

            elif line.startswith('#'):

                # Write previous scene.

                write_scene_content(scId, contentLines)
                scId = None

                # Add a chapter.

                self.prj.chCount += 1
                self.prj.chId = str(self.prj.chCount)
                self.prj.chapters[self.prj.chId] = Chapter()
                title = line.split(' ', maxsplit=1)[1]
                self.prj.chapters[self.prj.chId].title = title
                self.prj.chapters[self.prj.chId].chType = chType
                self.prj.chapters[self.prj.chId].isUnused = isUnused

                self.prj.srtChapters.append(self.prj.chId)

                if line.startswith('##'):
                    self.prj.chapters[self.prj.chId].chLevel = 0

                else:
                    self.prj.chapters[self.prj.chId].chLevel = 1

            elif scId is not None:
                contentLines.append(line)

        # Write the last scene of the file.

        write_scene_content(scId, contentLines)
        return('SUCCESS')


class NwxFile(Novel):
    """novelWriter project representation.
    """

    EXTENSION = '.nwx'
    DESCRIPTION = 'novelWriter project'
    SUFFIX = ''
    CONTENT_DIR = '/content/'
    CONTENT_EXTENSION = '.nwd'

    NWX_TAG = 'novelWriterXML'
    NWX_ATTR = {
        'appVersion': '1.6-alpha0',
        'hexVersion': '0x010600a0',
        'fileVersion': '1.3',
        'timeStamp': datetime.now().replace(microsecond=0).isoformat(sep=' '),
    }

    def __init__(self, filePath, **kwargs):
        """Extend the superclass constructor,
        defining instance variables.
        """
        Novel.__init__(self, filePath, **kwargs)

        self.tree = None
        self.kwargs = kwargs
        self.nwHandles = Handles()

        self.lcCount = 0
        self.lcIdsByName = {}

        self.crCount = 0
        self.crIdsByTitle = {}

        self.scCount = 0
        self.chCount = 0

        self.sceneStatus = kwargs['scene_status']

    def read_xml_file(self):
        """Read the novelWriter XML project file.
        Return a message beginning with SUCCESS or ERROR.
        """

        try:
            self.tree = ET.parse(self.filePath)

        except:
            return 'ERROR: Can not process "' + os.path.normpath(self.filePath) + '".'

        return 'SUCCESS: XML element tree read in.'

    def read(self):
        """Parse the files and store selected properties.
        Return a message beginning with SUCCESS or ERROR.
        Override the superclass method.
        """

        def add_nodes(node):
            """Add nodes to the novelWriter project tree of handles.
            """

            for item in content.iter('item'):
                parent = item.attrib.get('parent')

                if parent in node:
                    node[parent][item.attrib.get('handle')] = {}
                    add_nodes(node[parent])

        def get_nodes(id, list, subtree):
            """Get a list of file handles, passed as a parameter.
            This is for serializing a project subtree.
            """

            if nwItems[id].nwType == 'FILE':
                list.append(id)

            else:

                for subId in subtree[id]:
                    get_nodes(subId, list, subtree[id])

        #--- Read the XML file, if necessary.

        if self.tree is None:
            message = self.read_xml_file()

            if message.startswith('ERROR'):
                return message

        root = self.tree.getroot()

        # Check file type and version.

        if root.tag != self.NWX_TAG:
            return 'ERROR: This seems not to bee a novelWriter project file.'

        if root.attrib.get('fileVersion') != self.NWX_ATTR['fileVersion']:
            return 'ERROR: Wrong file version (must be ' + self.NWX_VERSION + ').'

        #--- Read project metadata from the xml element tree.

        prj = root.find('project')

        if prj.find('title') is not None:
            self.title = prj.find('title').text

        elif prj.find('name') is not None:
            self.title = prj.find('name').text

        authors = []

        for author in prj.iter('author'):
            authors.append(author.text)

        self.author = ', '.join(authors)

        #--- Read project content from the xml element tree.

        content = root.find('content')

        # Build a tree of handles.

        nwTree = {'None': {}}
        add_nodes(nwTree)

        # Collect items:

        nwItems = {}

        for node in content.iter('item'):
            item = NwItem()
            handle = item.read(node)

            if not self.nwHandles.add_member(handle):
                return 'ERROR: Invalid handle: ' + handle

            nwItems[handle] = item

        #--- Re-serialize the project tree to get lists of file handles.

        for id in nwTree['None']:

            if nwItems[id].nwClass == 'CHARACTER':
                charList = []
                get_nodes(id, charList, nwTree['None'])

            if nwItems[id].nwClass == 'WORLD':
                locList = []
                get_nodes(id, locList, nwTree['None'])

            if nwItems[id].nwClass == 'NOVEL':
                novList = []
                get_nodes(id, novList, nwTree['None'])

        #--- Get characters.

        for handle in charList:
            nwdFile = NwdCharacterFile(self, handle, nwItems[handle])
            message = nwdFile.read()

            if message.startswith('ERROR'):
                return message

        #--- Get locations.

        for handle in locList:
            nwdFile = NwdWorldFile(self, handle, nwItems[handle])
            message = nwdFile.read()

            if message.startswith('ERROR'):
                return message

        #--- Get chapters and scenes.

        for handle in novList:
            nwdFile = NwdNovelFile(self, handle, nwItems[handle])
            message = nwdFile.read()

            if message.startswith('ERROR'):
                return message

        return('SUCCESS')

    def merge(self, source):
        """Copy the yWriter project parts that can be mapped to the novelWriter project.
        Return a message beginning with SUCCESS or ERROR.
        Override the superclass method.
        """
        if source.title is not None:
            self.title = source.title

        else:
            self.title = ''

        if source.desc is not None:
            self.desc = source.desc

        else:
            self.desc = ''

        if source.author is not None:
            self.author = source.author

        else:
            self.author = ''

        if source.scenes is not None:
            self.scenes = source.scenes

        if source.srtChapters != []:
            self.srtChapters = source.srtChapters
            self.chapters = source.chapters

        if source.srtCharacters != []:
            self.srtCharacters = source.srtCharacters
            self.characters = source.characters

        if source.srtLocations != []:
            self.srtLocations = source.srtLocations
            self.locations = source.locations

        if source.srtItems != []:
            self.srtItems = source.srtItems
            self.items = source.items

        return 'SUCCESS'

    def write(self):
        """Write the novelFolder attributes to a new novelWriter project
        consisting of a set of different files.
        Return a message beginning with SUCCESS or ERROR.
        Override the superclass method.
        """

        root = ET.Element(self.NWX_TAG, self.NWX_ATTR)

        #--- Write project metadata.

        xmlPrj = ET.SubElement(root, 'project')

        if self.title:
            title = self.title

        else:
            title = 'New project'

        ET.SubElement(xmlPrj, 'name').text = title
        ET.SubElement(xmlPrj, 'title').text = title

        if self.author:
            authors = self.author.split(',')

        else:
            authors = ['']

        for author in authors:
            ET.SubElement(xmlPrj, 'author').text = author.strip()

        # Omit settings.

        world = ET.SubElement(root, 'settings')

        #--- Write content.

        content = ET.SubElement(root, 'content')

        attrCount = 0
        order = [0]
        # Use a list as a stack for the order within a level

        #--- Write novel folder.

        novelFolderHandle = self.nwHandles.create_member('novelFolderHandle')
        novelFolder = NwItem()
        novelFolder.nwHandle = novelFolderHandle
        novelFolder.nwOrder = order[-1]
        novelFolder.nwParent = 'None'
        novelFolder.nwName = 'Novel'
        novelFolder.nwType = 'ROOT'
        novelFolder.nwClass = 'NOVEL'
        novelFolder.nwExpanded = 'True'
        novelFolder.write(content)

        attrCount += 1
        order[-1] += 1
        # content level

        hasPartLevel = False
        isInChapter = False

        # Add novel items to the folder.

        order.append(0)
        # Level up from content to novel

        for chId in self.srtChapters:

            if self.chapters[chId].chLevel == 1:

                # Begin with a new part.

                hasPartLevel = True
                isInChapter = False

                #--- Write a new folder for this part.

                partFolderHandle = self.nwHandles.create_member(chId + self.chapters[chId].title + 'Folder')
                partFolder = NwItem()
                partFolder.nwHandle = partFolderHandle
                partFolder.nwOrder = order[-1]
                partFolder.nwParent = novelFolderHandle
                partFolder.nwName = self.chapters[chId].title
                partFolder.nwType = 'FOLDER'
                partFolder.nwClass = 'NOVEL'
                partFolder.expanded = 'True'

                partFolder.write(content)

                attrCount += 1
                order[-1] += 1
                # novel level

                order.append(0)
                # Level up from novel to part

                # Put the heading into the part folder.

                partHeadingHandle = self.nwHandles.create_member(chId + self.chapters[chId].title)
                partHeading = NwItem()
                partHeading.nwHandle = partHeadingHandle
                partHeading.nwOrder = order[-1]
                partHeading.nwParent = partFolderHandle
                partHeading.nwName = self.chapters[chId].title + ' (Heading)'
                partHeading.nwType = 'FILE'
                partHeading.nwClass = 'NOVEL'
                partHeading.nwExported = 'True'

                if self.chapters[chId].chType == 0:
                    partHeading.nwExported = 'True'

                else:
                    partHeading.nwExported = 'False'

                partHeading.nwLayout = 'DOCUMENT'
                partHeading.nwStatus = 'None'

                partHeading.write(content)

                partHeadingDoc = NwdNovelFile(self, partHeading)
                partHeadingDoc.lines.append('# ' + self.chapters[chId].title)
                partHeadingDoc.write()

                attrCount += 1
                order[-1] += 1
                # part level

                order.append(0)
                # Level up from part to chapter

            else:

                # Begin with a new chapter.

                isInChapter = True

                #--- Write a new folder for this chapter.

                chapterFolderHandle = self.nwHandles.create_member(chId + self.chapters[chId].title + 'Folder')
                chapterFolder = NwItem()
                chapterFolder.nwHandle = chapterFolderHandle
                chapterFolder.nwOrder = order[-1]

                if hasPartLevel:
                    chapterFolder.nwParent = partFolderHandle

                else:
                    chapterFolder.nwParent = novelFolderHandle

                chapterFolder.nwName = self.chapters[chId].title
                chapterFolder.nwType = 'FOLDER'
                chapterFolder.expanded = 'True'

                chapterFolder.write(content)

                attrCount += 1
                order[-1] += 1
                # part or novel level

                order.append(0)
                # Level up from part or novel to chapter

                # Put the heading into the folder.

                chapterHeadingHandle = self.nwHandles.create_member(chId + self.chapters[chId].title)
                chapterHeading = NwItem()
                chapterHeading.nwHandle = chapterHeadingHandle
                chapterHeading.nwOrder = order[-1]
                chapterHeading.nwParent = chapterFolderHandle
                chapterHeading.nwName = self.chapters[chId].title + ' (Heading)'
                chapterHeading.nwType = 'FILE'
                chapterHeading.nwClass = 'NOVEL'

                if self.chapters[chId].chType == 0:
                    chapterHeading.nwExported = 'True'

                else:
                    chapterHeading.nwExported = 'False'

                chapterHeading.nwLayout = 'DOCUMENT'
                chapterHeading.nwStatus = 'None'

                chapterHeading.write(content)
                chapterHeadingDoc = NwdNovelFile(self, chapterHeading)
                chapterHeadingDoc.lines.append('## ' + self.chapters[chId].title)
                chapterHeadingDoc.write()

                attrCount += 1
                order[-1] += 1
                # chapter level

            for scId in self.chapters[chId].srtScenes:

                #--- Put a scene into the folder.

                sceneHandle = self.nwHandles.create_member(scId + self.scenes[scId].title)
                scene = NwItem()
                scene.nwHandle = sceneHandle
                scene.nwOrder = order[-1]

                if isInChapter:
                    scene.nwParent = chapterFolderHandle

                else:
                    scene.nwParent = partFolderHandle

                if self.scenes[scId].title:
                    title = self.scenes[scId].title

                else:
                    title = 'Scene ' + str(order[-1] + 1)

                scene.nwName = title
                scene.nwType = 'FILE'
                scene.nwClass = 'NOVEL'

                if self.scenes[scId].status is not None:
                    scene.nwStatus = self.sceneStatus[self.scenes[scId].status]

                if self.scenes[scId].isUnused:
                    scene.nwExported = 'False'

                else:
                    scene.nwExported = 'True'

                if self.scenes[scId].isNotesScene or self.scenes[scId].isTodoScene:
                    scene.nwLayout = 'NOTE'

                else:
                    scene.nwLayout = 'DOCUMENT'

                if self.scenes[scId].wordCount:
                    scene.nwWordCount = str(self.scenes[scId].wordCount)

                if self.scenes[scId].letterCount:
                    scene.nwCharCount = str(self.scenes[scId].letterCount)

                scene.write(content)
                sceneDoc = NwdNovelFile(self, scene)

                if self.scenes[scId].appendToPrev:
                    sceneDoc.lines.append('#### ' + title)

                else:
                    sceneDoc.lines.append('### ' + title)

                sceneDoc.write()

                attrCount += 1
                order[-1] += 1
                # chapter or part level

            order.pop()
            # Level down from chapter to part or novel

            # if hasPartLevel:
            # order.pop()
            # Level down from part to novel

        order.pop()
        # Level down from novel to content

        #--- Write character folder.

        characterFolderHandle = self.nwHandles.create_member('characterFolderHandle')
        characterFolder = NwItem()
        characterFolder.nwHandle = characterFolderHandle
        characterFolder.nwOrder = order[-1]
        characterFolder.nwParent = 'None'
        characterFolder.nwName = 'Characters'
        characterFolder.nwType = 'ROOT'
        characterFolder.nwClass = 'CHARACTER'
        characterFolder.nwStatus = 'None'
        characterFolder.nwExpanded = 'True'

        characterFolder.write(content)

        attrCount += 1
        order[-1] += 1

        # Add character items to the folder.

        order.append(0)
        # Level up from world to character

        for crId in self.srtCharacters:

            #--- Put a character into the folder.

            characterHandle = self.nwHandles.create_member(crId + self.characters[crId].title)
            character = NwItem()
            character.nwHandle = characterHandle
            character.nwOrder = order[-1]
            character.nwParent = characterFolderHandle

            if self.characters[crId].fullName:
                character.nwName = self.characters[crId].fullName

            elif self.characters[crId].title:
                character.nwName = self.characters[crId].title

            else:
                character.nwName = 'Character ' + str(order[-1] + 1)

            character.nwType = 'FILE'
            character.nwClass = 'CHARACTER'

            if self.characters[crId].isMajor:
                character.nwStatus = 'Major'

            else:
                character.nwStatus = 'Minor'

            character.nwExported = 'True'
            character.nwLayout = 'NOTE'

            character.write(content)
            characterDoc = NwdCharacterFile(self, character)
            characterDoc.lines.append('# ' + self.characters[crId].title)
            characterDoc.write()

            attrCount += 1
            order[-1] += 1
            # character level

        order.pop()
        # Level down from character to content

        #--- Write world folder.

        worldFolderHandle = self.nwHandles.create_member('worldFolderHandle')
        worldFolder = NwItem()
        worldFolder.nwHandle = worldFolderHandle
        worldFolder.nwOrder = order[-1]
        worldFolder.nwParent = 'None'
        worldFolder.nwName = 'Locations'
        worldFolder.nwType = 'ROOT'
        worldFolder.nwClass = 'WORLD'
        worldFolder.nwStatus = 'None'
        worldFolder.nwExpanded = 'True'

        worldFolder.write(content)

        attrCount += 1
        order[-1] += 1
        # content level

        # Add world items to the folder.

        order.append(0)
        # Level up from content to world

        for lcId in self.srtLocations:

            #--- Put a location into the folder.

            locationHandle = self.nwHandles.create_member(lcId + self.locations[lcId].title)
            location = NwItem()
            location.nwHandle = locationHandle
            location.nwOrder = order[-1]
            location.nwParent = worldFolderHandle

            if self.locations[lcId].title:
                title = self.locations[lcId].title

            else:
                title = 'Place ' + str(order[-1] + 1)

            location.nwName = title
            location.nwType = 'FILE'
            location.nwClass = 'WORLD'
            location.nwExported = 'True'
            location.nwLayout = 'NOTE'

            location.write(content)
            locationDoc = NwdWorldFile(self, location)
            locationDoc.lines.append('# ' + title)
            locationDoc.write()

            attrCount += 1
            order[-1] += 1
            # world level

        order.pop()
        # Level down to content

        # Write the content counter.

        content.set('count', str(attrCount))

        #--- Format and write the XML tree.

        indent(root)
        self.tree = ET.ElementTree(root)
        self.tree.write(self.filePath, xml_declaration=True, encoding='utf-8')

        return 'SUCCESS: "' + os.path.normpath(self.filePath) + '" written.'


class NwConverter(YwCnvUi):
    """A converter class for yWriter and novelWriter."""

    def run(self, sourcePath, **kwargs):
        """Create source and target objects and run conversion.
        Override the superclass method.
        """

        if not os.path.isfile(sourcePath):
            self.ui.set_info_how('ERROR: File "' + os.path.normpath(sourcePath) + '" not found.')
            return

        fileName, fileExtension = os.path.splitext(sourcePath)
        srcDir = os.path.dirname(sourcePath).replace('\\', '/')

        if srcDir == '':
            srcDir = '.'

        if fileExtension == Yw7File.EXTENSION:
            sourceFile = Yw7File(sourcePath, **kwargs)
            title = fileName.replace(srcDir, '')
            prjDir = srcDir + '/' + title + '.nw'

            if os.path.isfile(prjDir + '/nwProject.lock'):
                self.ui.set_info_how('ERROR: Please exit novelWriter.')
                return

            try:
                os.makedirs(prjDir + NwxFile.CONTENT_DIR)

            except FileExistsError:
                extension = '.bak'
                i = 0

                while os.path.isdir(prjDir + extension):
                    extension = '.bk' + str(i).zfill(3)
                    i += 1

                    if i > 999:
                        self.ui.set_info_how('ERROR: Unable to back up the project.')
                        return

                os.replace(prjDir, prjDir + extension)
                self.ui.set_info_what('Backup folder "' + os.path.normpath(prjDir) + extension + '" saved.')
                os.makedirs(prjDir + NwxFile.CONTENT_DIR)

            targetFile = NwxFile(prjDir + '/nwProject.nwx', **kwargs)
            self.export_from_yw(sourceFile, targetFile)

        elif fileExtension == NwxFile.EXTENSION:
            sourceFile = NwxFile(sourcePath, **kwargs)

            prjDir = srcDir + '/../'
            message = sourceFile.read_xml_file()

            if message.startswith('ERROR'):
                return message

            root = sourceFile.tree.getroot()
            prj = root.find('project')

            if prj.find('title') is not None:
                title = prj.find('title').text

            elif prj.find('name') is not None:
                title = prj.find('name').text

            else:
                title = 'NewProject'

            fileName = prjDir + title + Yw7File.EXTENSION

            if os.path.isfile(fileName):

                if self.confirm_overwrite(fileName):
                    os.replace(fileName, fileName + '.bak')
                    self.ui.set_info_what('Backup file "' + os.path.normpath(sourcePath) + '.bak" saved.')

                else:
                    self.ui.set_info_what('Action canceled by user.')
                    return

            targetFile = Yw7File(fileName, **kwargs)
            self.create_yw7(sourceFile, targetFile)

        else:
            self.ui.set_info_how('ERROR: File type of "' + os.path.normpath(sourcePath) + '" not supported.')

SUFFIX = ''
APPNAME = 'yw2nw'

SETTINGS = dict(
    outline_status=['New', 'Notes'],
    draft_status=['Started', '1st Draft'],
    first_edit_status=['2nd Draft'],
    second_edit_status=['3rd Draft'],
    done_status=['Finished'],
    scene_status=['None', 'New', '1st Draft', '2nd Draft', '3rd Draft', 'Finished'],
    major_character_status=['Major', 'Main'],
    character_notes_heading='## Notes',
    character_goals_heading='## Goals',
    character_bio_heading='## Bio',
    world_element_aka_tag='AKA',
    world_element_tag_tag='tag',
    # part_heading_prefix='#',
    # chapter_heading_prefix='##',
    # scene_heading_prefix='###',
    # section_heading_prefix='####',
)

OPTIONS = dict(
)


def run(sourcePath, silentMode=True, installDir=''):

    if silentMode:
        ui = Ui('')

    else:
        ui = UiCmd('Converter between yWriter and novelWriter 0.1.3')

    #--- Try to get persistent configuration data

    sourceDir = os.path.dirname(sourcePath)

    if sourceDir == '':
        sourceDir = './'

    else:
        sourceDir += '/'

    iniFileName = APPNAME + '.ini'
    iniFiles = [installDir + iniFileName, sourceDir + iniFileName]

    configuration = Configuration(SETTINGS, OPTIONS)

    for iniFile in iniFiles:
        configuration.read(iniFile)

    kwargs = {'suffix': SUFFIX}
    kwargs.update(configuration.settings)
    kwargs.update(configuration.options)

    converter = NwConverter()
    converter.ui = ui
    converter.run(sourcePath, **kwargs)
    ui.start()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Converter between yWriter and novelWriter',
        epilog='')
    parser.add_argument('sourcePath',
                        metavar='Sourcefile',
                        help='The path of the .nwx or .yw7 file.')

    parser.add_argument('--silent',
                        action="store_true",
                        help='suppress error messages and the request to confirm overwriting')
    args = parser.parse_args()

    try:
        installDir = str(Path.home()).replace('\\', '/') + '/.pywriter/' + APPNAME + '/config/'

    except:
        installDir = ''

    run(args.sourcePath, args.silent, installDir)
